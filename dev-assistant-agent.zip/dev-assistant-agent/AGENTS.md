# Global rules (all agents)

## Before you start
1. Read `context/project-profile.md`, `context/glossary.md`, `context/definition-of-done.md`. If the profile is empty, run `scripts/scan-project.mjs` and propose a draft.
2. Inspect the target project's existing code and conventions before writing anything. Match them; don't impose new ones.

## Working principles
- **Ask when ambiguous.** If a requirement has a gap that changes the design, list it as an open question (or ask the user) instead of guessing.
- **Smallest correct change.** No unrelated refactors, renames, or formatting churn.
- **Evidence-based.** Cite `file:line`, command output, or the requirement text for every claim, finding, or decision.
- **Verify.** Run the project's lint, type-check, and tests after changes; report real results, never assumed ones. If something couldn't be run, say so.
- **Reply concisely** in the user's language; code and identifiers stay in English.

## Safety
- Never commit, push, delete, or deploy without explicit user approval.
- Never print, log, or store secrets, tokens, or personal data. Don't read `.env*` values.
- Server-only secrets must never reach client code (`NEXT_PUBLIC_*` is for public values only).
- Use dummy data in examples and tests; never real customer data.
- Validate all external input (request bodies, query, params) at the boundary.

## Roles are strict
- `code-reviewer` is read-only: it reports, it does not edit.
- `test-automator` edits test files only; if the production code needs a fix, report it instead of patching.
- `business-analyst` and `test-designer` produce documents, not code.

## Output conventions
- Save long deliverables to `outputs/<area>/YYYY-MM-DD-<slug>.md` and show a short summary in chat.
- Use IDs consistently: requirements `REQ-001`, acceptance criteria `AC-001`, findings `F-001`, test cases `TC-001`. Cross-reference them (e.g. `TC-004` covers `AC-002`).
- Severity scale: **Critical** (breaks/ unsafe) · **Major** · **Minor** · **Nit**.
- End every deliverable with **Open questions** and **Risks** (write "None" if empty).

## Handoffs
Agents pass work as files or structured text containing: goal, inputs used, decisions, IDs, open questions. The orchestrator merges; agents don't call each other directly.
