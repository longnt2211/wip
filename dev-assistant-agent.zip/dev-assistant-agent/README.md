# Dev Assistant Agent

A daily-work assistant for a full-stack (FE + BE) developer. One orchestrator routes your request to specialist agents for **business analysis, code creation, code review, and test automation**, then merges the results.

## Quick start

Describe the job in chat, or use a prompt shortcut:

| You say | What happens |
|---------|--------------|
| "Analyze this requirement: ..." | `business-analyst` → stories, acceptance criteria, impact, open questions |
| "Review my changes" | `code-reviewer` on the git diff → severity-ranked report |
| "Create the feature: ..." | analyst → `code-creator-be` + `code-creator-fe` → tests → review |
| "Write tests for src/x.ts" | `test-designer` → `test-automator` (writes and runs them) |
| "Document this change" | `doc-writer` → PR description / README / API docs |

Shortcut prompts live in [prompts/](./prompts).

## Layout

```
AGENTS.md                global rules every agent follows
agents/                  one file per agent (role, inputs, outputs, rules)
skills/                  reusable playbooks (SKILL.md + references/templates)
prompts/                 short commands for common jobs
scripts/                 helper scripts (diff collector, project scanner, test runner)
context/                 project knowledge agents read first (EDIT THESE for your project)
outputs/                 generated reports/drafts (gitignored)
```

## Set up for a project

1. Fill in [context/project-profile.md](./context/project-profile.md) (stack, commands, conventions), or let the agent draft it:
   `node scripts/scan-project.mjs <project-root>`
2. Add business terms to [context/glossary.md](./context/glossary.md) and adjust [context/definition-of-done.md](./context/definition-of-done.md).
3. Make the agents available to your tool (copy or symlink `agents/` and `skills/` into the project's `.github/` or `.claude/`, or point your tool at this folder).

## Helper scripts (Node 18+, no dependencies)

```bash
node scripts/scan-project.mjs <project-root>            # stack, scripts, test tools -> JSON
node scripts/collect-diff.mjs [base-ref] [--staged]     # git diff summary for review
node scripts/run-tests.mjs <project-root> [-- args]     # run tests -> JSON summary
```

## Agents

| Agent | Role | Edits code? |
|-------|------|-------------|
| [main-orchestrator](./agents/main-orchestrator.md) | Route, parallelize, merge | No |
| [business-analyst](./agents/business-analyst.md) | Requirements → stories, AC, impact | No |
| [code-creator-fe](./agents/code-creator-fe.md) | Next.js/React UI code | Yes |
| [code-creator-be](./agents/code-creator-be.md) | API/service/DB code | Yes |
| [code-reviewer](./agents/code-reviewer.md) | Review diffs/files | **Never** |
| [test-designer](./agents/test-designer.md) | Test plan and cases | No |
| [test-automator](./agents/test-automator.md) | Write and run tests | Tests only |
| [doc-writer](./agents/doc-writer.md) | Docs, PR text, changelog | Docs only |
