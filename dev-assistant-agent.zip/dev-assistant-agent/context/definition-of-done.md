# Definition of Done

A change is done when:

## Code
- [ ] Meets every acceptance criterion (`AC-xxx`) of the story
- [ ] Follows project conventions; no unrelated changes; no leftover debug code/TODOs
- [ ] Input validated at boundaries; auth/ownership checks in place; no secrets in code or logs
- [ ] FE: loading, error, empty, and success states; accessible (labels, focus, keyboard)

## Quality gates (real results, not assumed)
- [ ] Type-check passes
- [ ] Lint passes
- [ ] New/changed behavior has automated tests (`TC-xxx` linked to AC); all tests pass
- [ ] No tests skipped or weakened

## Review & docs
- [ ] Code review done; no open Critical/Major findings
- [ ] PR description written (what/why/how to test/risks), tickets linked
- [ ] Docs/API docs/changelog updated if behavior or contract changed

## Release safety
- [ ] Migrations reversible and reviewed; rollout/rollback plan noted when risky
- [ ] No new dependencies without justification
