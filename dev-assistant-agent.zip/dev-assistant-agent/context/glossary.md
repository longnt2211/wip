# Glossary (EDIT ME)

Business terms the agents must use consistently (in specs, code names, UI text, and tests).

| Term | Definition | Code name / table | Notes |
|---|---|---|---|
| <Product> | <what it means in this business> | `Product` / `products` | <synonyms to avoid> |
| <Order> | | | |
