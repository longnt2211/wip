# Project profile (EDIT ME)

> Fill this in once per project. Agents read it before working. Tip: `node scripts/scan-project.mjs <project-root>` prints a draft.

## Overview
- Name: <project>
- Purpose / domain: <one line>
- Repo / root path: <path>

## Stack
- Frontend: <Next.js version, App Router/Pages, React, TypeScript strict?, Tailwind/UI lib>
- Backend: <route handlers / Express / Nest>, runtime <Node version>
- Database / ORM: <Postgres/MySQL/Mongo, Prisma/Drizzle/...>
- Auth: <NextAuth/Clerk/custom>
- Data fetching/state: <TanStack Query/SWR/Zustand/...>
- Validation: <zod/yup/...>

## Commands
| Task | Command |
|---|---|
| Install | `npm install` |
| Dev | `npm run dev` |
| Build | `npm run build` |
| Lint | `npm run lint` |
| Type-check | `npx tsc --noEmit` |
| Unit/component tests | `<npm test>` |
| E2E tests | `<npx playwright test>` |

## Conventions
- Folder layout: <where pages, components, lib, types, tests live>
- Naming: <files, components, hooks>
- API response/error shape: <...>
- Styling approach: <...>
- Git: <branch naming, commit style>

## Environments & secrets
- Env var **names** only (never values): <DATABASE_URL, NEXTAUTH_SECRET, ...>
- Dev DB safe to migrate? <yes/no>

## Known constraints / gotchas
- <e.g., legacy module X must not be changed; browser support; i18n languages>
