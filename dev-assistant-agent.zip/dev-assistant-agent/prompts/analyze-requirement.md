Use the `main-orchestrator` agent → `business-analyst`.

Analyze this requirement and produce a spec (stories `REQ-`, acceptance criteria `AC-` in Given/When/Then, business rules, edge cases, impact analysis, API contract sketch, open questions ranked by blocking level):

<paste ticket / requirement / notes here>

Context (optional): <existing modules, constraints, deadline>
Save to `outputs/analysis/`. Ask me only about blockers.
