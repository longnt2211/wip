Use the `main-orchestrator` agent with the "Feature end-to-end" pipeline.

Create this feature in project `<path>`:

<paste spec or ticket here; or path to outputs/analysis/...>

Steps: analyze (stop and ask on blockers) → backend and frontend implementation (match existing conventions) → tests from acceptance criteria (run them) → code review → PR description.
Constraints: <no new dependencies | must work with existing auth | ...>
Do not commit, push, or run migrations on non-dev data.
