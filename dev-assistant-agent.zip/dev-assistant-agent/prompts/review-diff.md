Use the `main-orchestrator` agent → `code-reviewer` (read-only).

Review: <uncommitted changes | staged | branch vs main | files: a.ts, b.tsx>
Focus: <all | security | performance | quality | tests>
Spec / AC (optional): <paste or path to outputs/analysis/...>

Start with `node scripts/collect-diff.mjs [base-ref] [--staged]`. Return a severity-ranked report (verdict, findings F-001… with file:line, impact, fix; requirement coverage; test gaps; positives). Do not edit any code.
