Use the `main-orchestrator` agent → `test-designer` → `test-automator`.

Write automated tests for: <file(s) | feature | AC ids>
Levels: <unit | component | API | E2E | let the designer decide>
Project: <path>

Detect the existing test setup (`node scripts/scan-project.mjs <path>`), reuse it, then plan (`TC-` ↔ `AC-` traceability), implement, run (`node scripts/run-tests.mjs <path>`), and report real results. Don't patch production code or skip tests; report product bugs separately.
