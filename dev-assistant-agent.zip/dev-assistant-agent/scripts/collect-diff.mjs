#!/usr/bin/env node
// Collect a git diff for review. Read-only (never changes the repo).
// Usage: node collect-diff.mjs [base-ref] [--staged] [--repo <path>] [--out <file>] [--max-kb 400]
//   no base-ref : uncommitted changes (working tree vs HEAD)
//   base-ref    : changes on the current branch since the merge-base with <base-ref> (e.g. main)

import { spawnSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const args = process.argv.slice(2);
const opt = (n, d) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : d; };
const staged = args.includes('--staged');
const repo = resolve(opt('--repo', '.'));
const out = opt('--out');
const maxKb = Number(opt('--max-kb', 400));
const base = args.find((a, i) => !a.startsWith('--') && !['--repo', '--out', '--max-kb'].includes(args[i - 1]));

const git = (...a) => spawnSync('git', ['-C', repo, ...a], { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });

const inside = git('rev-parse', '--is-inside-work-tree');
if (inside.status !== 0) { console.error(`Not a git repository: ${repo}`); process.exit(1); }

let range = [];
let label;
if (staged) { range = ['--cached']; label = 'staged changes'; }
else if (base) {
  const mb = git('merge-base', base, 'HEAD');
  if (mb.status !== 0) { console.error(`Cannot find merge-base with "${base}"`); process.exit(1); }
  range = [mb.stdout.trim(), 'HEAD']; label = `HEAD vs merge-base(${base})`;
} else { range = ['HEAD']; label = 'working tree vs HEAD'; }

const names = git('diff', '--name-status', ...range).stdout.trim();
const stat = git('diff', '--stat', ...range).stdout.trim();
let diff = git('diff', '--unified=5', '--no-color', ...range).stdout;
const untracked = !staged && !base ? git('ls-files', '--others', '--exclude-standard').stdout.trim() : '';

let truncated = false;
if (diff.length > maxKb * 1024) { diff = diff.slice(0, maxKb * 1024); truncated = true; }

const report = [
  `# Diff: ${label}`,
  '',
  `## Files (status)\n${names || '(none)'}`,
  untracked ? `\n## Untracked files (not in diff; read them directly)\n${untracked}` : '',
  `\n## Stat\n${stat || '(none)'}`,
  `\n## Patch${truncated ? ` (truncated at ${maxKb} KB; review remaining files directly)` : ''}\n\`\`\`diff\n${diff}\n\`\`\``,
].join('\n');

if (out) { writeFileSync(out, report); console.log(`Wrote ${out} (${names.split('\n').filter(Boolean).length} files changed)`); }
else console.log(report);
