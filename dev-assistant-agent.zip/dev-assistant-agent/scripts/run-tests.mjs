#!/usr/bin/env node
// Run a project's tests and print a JSON summary (command, exit code, duration, output tail).
// Usage: node run-tests.mjs <project-root> [-- extra test args]
// Uses the project's own "test" script; falls back to playwright/vitest/jest if no script exists.

import { spawnSync } from 'node:child_process';
import { readFileSync, existsSync } from 'node:fs';
import { join, resolve } from 'node:path';

const argv = process.argv.slice(2);
const sep = argv.indexOf('--');
const extra = sep >= 0 ? argv.slice(sep + 1) : [];
const root = resolve((sep >= 0 ? argv.slice(0, sep) : argv)[0] || '.');
const pkgPath = join(root, 'package.json');
if (!existsSync(pkgPath)) { console.error(`No package.json in ${root}`); process.exit(2); }

const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'));
const deps = { ...pkg.dependencies, ...pkg.devDependencies };
const pm = existsSync(join(root, 'pnpm-lock.yaml')) ? 'pnpm' : existsSync(join(root, 'yarn.lock')) ? 'yarn' : 'npm';

let cmd;
if (pkg.scripts?.test && !/no test specified/.test(pkg.scripts.test)) cmd = `${pm} test${extra.length ? (pm === 'npm' ? ' --' : '') + ' ' + extra.join(' ') : ''}`;
else if (deps.vitest) cmd = `npx vitest run ${extra.join(' ')}`;
else if (deps.jest) cmd = `npx jest ${extra.join(' ')}`;
else if (deps['@playwright/test']) cmd = `npx playwright test ${extra.join(' ')}`;
else { console.error('No test runner or test script found.'); process.exit(2); }

const started = Date.now();
const r = spawnSync(cmd, { cwd: root, shell: true, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024, env: { ...process.env, CI: '1', FORCE_COLOR: '0' } });
const output = `${r.stdout || ''}\n${r.stderr || ''}`.replace(/\x1b\[[0-9;]*m/g, '');

const num = (re) => { const m = output.match(re); return m ? Number(m[1]) : null; };
const summary = {
  command: cmd,
  cwd: root,
  exitCode: r.status,
  passed: r.status === 0,
  durationMs: Date.now() - started,
  counts: {
    passed: num(/(\d+)\s+passed/i),
    failed: num(/(\d+)\s+failed/i),
    skipped: num(/(\d+)\s+(?:skipped|pending)/i),
  },
  outputTail: output.trim().split('\n').slice(-60).join('\n'),
};

console.log(JSON.stringify(summary, null, 2));
process.exit(r.status === 0 ? 0 : 1);
