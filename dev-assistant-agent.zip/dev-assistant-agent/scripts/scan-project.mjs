#!/usr/bin/env node
// Print a JSON profile of a JS/TS project: stack, scripts, test tools, folders. Read-only.
// Usage: node scan-project.mjs <project-root>

import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { join, resolve } from 'node:path';

const root = resolve(process.argv[2] || '.');
const pkgPath = join(root, 'package.json');
if (!existsSync(pkgPath)) {
  console.error(`No package.json in ${root}`);
  process.exit(1);
}

const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'));
const deps = { ...pkg.dependencies, ...pkg.devDependencies };
const has = (...names) => names.filter((n) => deps[n]);
const dir = (p) => existsSync(join(root, p)) && statSync(join(root, p)).isDirectory();
const file = (...ps) => ps.filter((p) => existsSync(join(root, p)));

const pm = file('pnpm-lock.yaml').length ? 'pnpm' : file('yarn.lock').length ? 'yarn' : file('bun.lockb', 'bun.lock').length ? 'bun' : 'npm';
const run = (s) => (pm === 'npm' ? `npm run ${s}` : `${pm} ${s}`);

const testFiles = [];
(function walk(d, depth = 0) {
  if (depth > 6) return;
  for (const n of readdirSync(d)) {
    if (['node_modules', '.next', '.git', 'dist', 'build', 'coverage'].includes(n)) continue;
    const p = join(d, n);
    const s = statSync(p);
    if (s.isDirectory()) walk(p, depth + 1);
    else if (/\.(test|spec)\.(t|j)sx?$/.test(n)) testFiles.push(p.slice(root.length + 1).replace(/\\/g, '/'));
  }
})(root);

const out = {
  name: pkg.name,
  root,
  packageManager: pm,
  stack: {
    next: deps.next || null,
    react: deps.react || null,
    typescript: deps.typescript || null,
    tailwind: !!deps.tailwindcss,
    backend: has('express', 'fastify', '@nestjs/core', 'koa', 'hono'),
    orm: has('prisma', '@prisma/client', 'drizzle-orm', 'typeorm', 'mongoose', 'sequelize'),
    auth: has('next-auth', '@auth/core', '@clerk/nextjs', 'passport', 'jsonwebtoken'),
    validation: has('zod', 'yup', 'joi', 'class-validator'),
    dataFetching: has('@tanstack/react-query', 'swr', 'axios', 'zustand'),
  },
  routerType: dir('app') || dir('src/app') ? 'app' : dir('pages') || dir('src/pages') ? 'pages' : null,
  tests: {
    unit: has('jest', 'vitest', 'mocha'),
    component: has('@testing-library/react'),
    e2e: has('@playwright/test', 'playwright', 'cypress'),
    configFiles: file('jest.config.js', 'jest.config.ts', 'vitest.config.ts', 'vitest.config.js', 'playwright.config.ts', 'cypress.config.ts'),
    testFileCount: testFiles.length,
    sampleTestFiles: testFiles.slice(0, 5),
  },
  commands: {
    dev: pkg.scripts?.dev ? run('dev') : null,
    build: pkg.scripts?.build ? run('build') : null,
    lint: pkg.scripts?.lint ? run('lint') : null,
    test: pkg.scripts?.test ? (pm === 'npm' ? 'npm test' : `${pm} test`) : null,
    typecheck: deps.typescript ? 'npx tsc --noEmit' : null,
    allScripts: Object.keys(pkg.scripts || {}),
  },
  folders: ['app', 'src', 'pages', 'components', 'lib', 'hooks', 'types', 'prisma', 'tests', '__tests__', 'e2e'].filter(dir),
  envExample: file('.env.example', '.env.sample'),
};

console.log(JSON.stringify(out, null, 2));
