---
name: code-generation
description: "Use when: implementing features, endpoints, components, hooks, services, or migrations in a Next.js/React/TypeScript + Node project from a spec or acceptance criteria, following the project's existing conventions. Covers planning, layering, validation, error handling, security, and self-verification. Triggers on 'implement', 'create feature', 'add endpoint', 'build page/component', 'write the code'."
---

# Code Generation

## Workflow
1. **Understand**: read the spec/AC and `context/project-profile.md`. If no spec exists, ask the orchestrator to run `business-analyst` first for anything non-trivial.
2. **Explore** the codebase: similar features, naming, folder layout, shared utilities, styling, data layer. Reuse before creating. See [references/project-conventions.md](./references/project-conventions.md).
3. **Plan**: list files to add/change and the contract between FE and BE. Keep changes small and cohesive.
4. **Implement** (BE → contract → FE when both are needed):
   - Types first (request/response/DTO), then logic, then wiring.
   - Validate input at boundaries; consistent error shape; typed everything.
   - Handle loading/error/empty/success on the FE; accessible markup.
5. **Self-check**: type-check, lint, run affected tests; read your own diff for leftovers (debug logs, TODOs, unused code).
6. **Hand off**: file list, how to try it, assumptions, deferred items. Tests go to `test-automator`; review to `code-reviewer`.

## Rules
- Match existing style; no drive-by refactors; no new dependencies unless justified.
- Secrets stay server-side; validate and authorize on the server even if the UI also checks.
- No real data in fixtures/examples; no hard-coded environment values.
- Prefer boring, readable code over clever code; comments only where intent isn't obvious.
- Never run destructive or irreversible commands (migrations on non-dev DBs, deletes) without user approval.

## Definition of done
See `context/definition-of-done.md`.
