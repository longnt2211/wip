# Default conventions (override with context/project-profile.md and the project's own code)

The project's existing patterns always win. Use these only where the project has none.

## Folder layout (Next.js App Router)
```
app/                    routes: page.tsx, layout.tsx, loading.tsx, error.tsx, api/**/route.ts
components/             UI components (ui/, features/<feature>/)
lib/                    server utilities, data access, clients (server-only where needed)
hooks/                  client hooks
types/                  shared types/DTOs
tests/ or __tests__/    tests mirroring source paths
```

## Layering (backend)
`route handler (parse + auth + respond)` → `service (business rules)` → `repository/data access`
- Handlers are thin; services hold rules and are unit-testable without HTTP.
- Return DTOs, never raw DB rows with internal fields.

## API conventions
- Success: `{ data: ... }` (lists add `{ meta: { page, pageSize, total } }`).
- Error: `{ error: { code, message, details? } }` with correct status (400 validation, 401, 403, 404, 409, 422, 429, 500).
- Validate with zod (or the project's validator) at the boundary; parse, don't trust.

## TypeScript
- `strict` on; no `any` (use `unknown` + narrowing); explicit return types on exported functions.
- Shared DTO types in `types/`; derive from zod schemas where possible (`z.infer`).

## React / Next.js
- Server components by default; `'use client'` for interactivity only.
- Data fetching through the project's pattern (server fetch, route handler + query hook, or server action).
- Forms: label + input pairs, inline errors, disabled-while-pending submit.
- Styling: project's system (Tailwind tokens/components); don't introduce a second approach.

## Naming
- Files: components `PascalCase.tsx`, hooks `useThing.ts`, utilities `kebab-case.ts` (follow the project if different).
- Booleans `is/has/can…`; handlers `handleX`; constants `UPPER_SNAKE`.

## Errors, logging, config
- Throw typed errors in services; map to HTTP in one place.
- Log events with ids, never secrets/PII. Config via validated env module; names only in docs.
