---
name: code-review
description: "Use when: reviewing a diff, branch, PR, or files for bugs, security, performance, error handling, accessibility, readability, and test gaps in Next.js/React/TypeScript front-end and Node back-end code. Returns a severity-ranked report with concrete fixes. Read-only. Triggers on 'review', 'check my code', 'PR review', 'find bugs', 'security review of changes'."
---

# Code Review

## Workflow
1. **Collect**: `node scripts/collect-diff.mjs [base-ref] [--staged]` (or read the given files). Read surrounding code, callers, and types; hunks alone mislead.
2. **Understand intent**: spec/AC/PR text. Check the change does that and nothing risky beyond.
3. **Review in priority order**: Correctness → Security → Data integrity → Error handling → Performance → Accessibility/UX (FE) → Readability/maintainability → Tests.
   Use [references/checklist-be.md](./references/checklist-be.md) and [references/checklist-fe.md](./references/checklist-fe.md).
4. **Verify** each suspicion (trace the code path); drop what you can't support.
5. **Report** (format in `agents/code-reviewer.md`): verdict, findings `F-001…` with Where/Problem/Impact/Fix, requirement coverage, test gaps, positives, open questions.

## Severity
- **Critical**: security hole, data loss/corruption, crash on main path, secret exposure.
- **Major**: wrong behavior in realistic cases, missing auth/validation, race condition, serious perf issue.
- **Minor**: maintainability, missing edge-case handling, unclear naming with real cost.
- **Nit**: optional polish (keep to a handful, never block on it).

## Rules
- Read-only. No edits, no commits.
- High signal: skip what linters/formatters already enforce.
- Every finding: file:line, why it matters, a concrete fix.
- Praise what's solid so the author knows what to keep.
