# Back-end review checklist

## Correctness
- Logic matches AC; boundary values (0, 1, max, empty, null/undefined).
- Async: missing `await`, unhandled promise rejections, race conditions, double-submit/idempotency.
- Timezones/dates, money (no float math), pagination off-by-one, sorting stability.

## Security
- AuthN on every protected route; **AuthZ/ownership checks** (IDOR): can user A access user B's record by changing an id?
- Input validated at the boundary (type, length, format, enum); output encoded.
- SQL/NoSQL injection (raw queries, string-built filters), command/path injection, SSRF on user-supplied URLs.
- Secrets in code/logs/responses; PII in logs; error messages leaking internals/stack traces.
- Mass assignment (spreading request body into DB model), over-broad `select *` returned to clients.
- CSRF/CORS/cookie flags (`httpOnly`, `secure`, `sameSite`), rate limiting on auth and expensive endpoints.
- File upload: type/size checks, storage path, content-disposition.
- Dependencies: new packages justified and maintained.

## Data
- Transactions around multi-step writes; unique constraints for uniqueness rules; cascading deletes intended.
- Migrations: reversible, safe on large tables (locks), defaults/backfill, indexes for new filters.
- N+1 queries, unbounded result sets, missing indexes.

## Errors & observability
- Consistent error shape and status codes; no swallowed errors; retries only for idempotent calls with backoff.
- Useful, non-sensitive logs with correlation ids; timeouts on outbound calls.

## Design & tests
- Thin controllers, logic in services; no duplicated rules; clear naming.
- Tests cover AC, error paths, and permission cases; mocks don't hide the behavior under test.
