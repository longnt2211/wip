# Front-end review checklist (Next.js / React / TypeScript)

## Correctness
- Matches AC for happy path, validation, empty, loading, and error states.
- Hooks rules; stale closures; missing/extra effect dependencies; effects that should be derived state or event handlers.
- Keys on lists (stable ids, not index when reordering); controlled/uncontrolled input mixing.
- Race conditions in fetching (out-of-order responses, no cancellation); double submit.
- `useEffect` fetching where a server component or query library fits better.

## Next.js specifics
- Server vs client boundary: `'use client'` only where needed; no server-only code/secrets imported into client files.
- No `NEXT_PUBLIC_` for secrets; data fetching/caching intent explicit (`no-store`, revalidate).
- `loading.tsx`/`error.tsx`/`not-found.tsx` for data routes; `next/image` with dimensions/`sizes`; `next/link` for navigation; metadata set.
- Hydration risks: `Date.now()`, `Math.random()`, `window` access during render.

## Security
- XSS: `dangerouslySetInnerHTML`, unsanitized HTML, user-controlled `href` (`javascript:`).
- Tokens in localStorage/URL; sensitive data in client state or logs.
- Open redirects after login (`redirect` params).

## Accessibility & UX
- Semantic elements (`button`, `a`, `label`), labels tied to inputs, alt text, focus visible, keyboard operation, aria for dynamic messages/icon-only buttons.
- Buttons disabled/progress while pending; helpful error messages; confirmation for destructive actions.
- Contrast and touch targets; responsive layout; no layout shift.

## Performance
- Unneeded client components/large bundles (heavy libs; use `dynamic()`); re-render hot spots; expensive work in render without memo (only when measured).
- Image/font handling; avoid waterfalls (parallel fetching).

## Types & maintainability
- No `any`/unsafe casts hiding bugs; props typed; zod/schema parse of external data.
- Reuse existing components/hooks; consistent styling tokens; clear names; small components.

## Tests
- Meaningful assertions on behavior (roles/text), not implementation; async handled with `findBy`/`waitFor`.
