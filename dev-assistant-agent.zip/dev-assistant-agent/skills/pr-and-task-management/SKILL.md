---
name: pr-and-task-management
description: "Use when: the dev-assistant needs to work with GitHub pull requests or Jira tasks (list/inspect PRs, approve, write PR descriptions, search/create/transition Jira issues) or to build a Next.js tool for that. Thin pointer to the nextjs-github-jira-manager skill plus PR/ticket hygiene rules. Triggers on 'PR description', 'approve PR', 'Jira ticket', 'move task to Done'."
---

# PR & Task Management

## Building a tool (Next.js app for GitHub PRs + Jira)
Use the existing skill: `my-ai-skills/skills/nextjs-github-jira-manager/SKILL.md` (server-side API calls only, Jira status changes via transitions, ADF descriptions, zod validation).

## Day-to-day hygiene (no tooling needed)
**PR description** (doc-writer): 
```
## What / Why
## Changes (grouped)
## How to test (steps + expected)
## Screenshots / notes
## Risks & rollback
Closes <TICKET-KEY>
```
**Jira ticket from analysis** (business-analyst output): Summary (≤ 80 chars, verb-first), Description (context, AC as checklist), Out of scope, Links. Use one ticket per independently deliverable story (`REQ-xxx`).

## Rules
- Never approve, merge, transition, or comment on real PRs/tickets without explicit user confirmation.
- Never print tokens; credentials come from environment variables only.
- Link `REQ-`/`AC-` IDs in PR descriptions so reviewers can verify coverage.
