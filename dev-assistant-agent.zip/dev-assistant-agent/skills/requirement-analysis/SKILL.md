---
name: requirement-analysis
description: "Use when: turning a ticket, idea, or vague request into a testable spec - user stories, Given/When/Then acceptance criteria, business rules, edge cases, impact analysis (UI/API/DB/security), API contract sketch, and open questions. Triggers on 'analyze requirement', 'clarify ticket', 'write user stories', 'acceptance criteria', 'impact analysis'."
---

# Requirement Analysis

## Workflow
1. **Restate** the goal, user, and problem (2-3 lines).
2. **Clarify**: list ambiguities. Ask the user only for blockers; label the rest as assumptions.
3. **Write stories** using [templates/user-story.md](./templates/user-story.md): `REQ-001…`, each with AC in Given/When/Then (`AC-001…`).
4. **Cover edge cases**: empty/none, duplicates, limits/boundaries, invalid input, permissions, concurrency, failure of dependencies, i18n/timezone, mobile/slow network.
5. **Impact analysis** using [templates/impact-analysis.md](./templates/impact-analysis.md): UI, API, data/migrations, integrations, security/privacy, performance, analytics, rollout.
6. **Contract sketch** (if FE+BE are involved): endpoint list with request/response/error examples so both sides can start in parallel.
7. **Size and order**: S/M/L per story, dependencies, suggested delivery slices.
8. **Save** to `outputs/analysis/YYYY-MM-DD-<slug>.md`; end with Open questions and Risks.

## Quality bar
- Every AC is observable and testable with concrete values/limits.
- Each story states who benefits and why (value).
- No solution lock-in unless a constraint requires it.
- Unknowns are explicit; assumptions are labelled `ASSUMPTION:`.

## Anti-patterns
Vague words ("fast", "easy"), hidden scope, ACs that describe implementation, missing error paths, skipping permissions.
