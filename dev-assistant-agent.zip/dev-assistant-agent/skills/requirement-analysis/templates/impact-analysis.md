# Impact analysis: <title>

| Area | Impact (None / Low / Med / High) | Details / files / modules |
|---|---|---|
| UI (pages, components, navigation) | | |
| API (new/changed endpoints, breaking?) | | |
| Data model (tables, indexes, migration, backfill) | | |
| Auth & permissions | | |
| Integrations (3rd party, queues, email) | | |
| Security & privacy (PII, secrets, input validation) | | |
| Performance & scale (queries, caching, payload size) | | |
| Observability (logs, metrics, alerts) | | |
| Analytics / tracking events | | |
| Tests (new/changed suites) | | |
| Docs | | |

## Compatibility
- Backward compatible? <yes/no, how>
- Feature flag / phased rollout? <plan>
- Rollback plan: <steps>

## Dependencies & sequencing
1. <what must land first>
