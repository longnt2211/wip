# Requirement analysis: <title>

- **Source**: <ticket/link/date>
- **Goal**: <one line>
- **Actors**: <roles>

## Stories

### REQ-001 <short title> (Size: S|M|L, Priority: P0|P1|P2)
**As a** <role> **I want** <capability> **so that** <value>.

**Business rules**
- BR-1: ...

**Acceptance criteria**
- AC-001: Given <context> When <action> Then <observable result>
- AC-002 (error): Given <invalid input> When <submit> Then <message/status, no data saved>
- AC-003 (permission): Given <role without access> When <action> Then <403/hidden>

**Edge cases**: empty · duplicate · max length · concurrent edit · dependency down

**Out of scope**: ...

## API contract sketch (if needed)
| Method | Path | Auth | Request | Success | Errors |
|---|---|---|---|---|---|
| POST | /api/... | user | `{...}` | 201 `{...}` | 400 validation, 401, 403, 409 |

## Assumptions
- ASSUMPTION: ...

## Open questions (blocking first)
1. [BLOCKER] ...
2. ...

## Risks
- ...
