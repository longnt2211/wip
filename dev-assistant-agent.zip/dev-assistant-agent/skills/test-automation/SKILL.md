---
name: test-automation
description: "Use when: designing, writing, running, or debugging automated tests for a Next.js/React/TypeScript + Node project - unit (Jest/Vitest), component (Testing Library), API/integration, and E2E (Playwright) - with AC traceability, deterministic data, and honest pass/fail reporting. Triggers on 'write tests', 'test plan', 'automate testing', 'increase coverage', 'flaky test', 'E2E'."
---

# Test Automation

## Workflow
1. **Discover**: `node scripts/scan-project.mjs <root>` → runner (Jest/Vitest/Playwright/Cypress), scripts, existing test folders and helpers. Reuse them. Install new tooling only if none exists, and say so.
2. **Plan** (test-designer): map `AC-xxx` → `TC-xxx`, choose level (unit → integration/API → E2E for critical journeys only), define data and mocks. Use [references/test-pyramid.md](./references/test-pyramid.md).
3. **Implement** (test-automator) from templates in [templates/](./templates): unit, API, component, E2E. Name tests with their `TC-` ID.
4. **Run**: `node scripts/run-tests.mjs <root>` (or the project's command). Read each failure.
5. **Triage** failures: test bug → fix; product bug → report with evidence (don't patch prod code); flaky/env → stabilize or report.
6. **Stabilize**: run new E2E/async tests at least twice; remove sleeps, use auto-waiting/`findBy`.
7. **Report**: command, totals, per-`TC` status, product bugs, flakiness risks, coverage delta.

## Rules
- Deterministic: fake timers/clock, seeded/dummy data, mocked network, isolated state, cleanup after each test.
- Assert behavior and outcomes users/clients see, not implementation details.
- One behavior per test; Arrange-Act-Assert; descriptive names.
- Never `.skip`, delete, or weaken a test to get green. Never hit real services or real data.
- Selectors: roles/labels/text (and `data-testid` only as a fallback).
- E2E: few, critical, independent journeys; log in via API/storage state, not through the UI every time.
