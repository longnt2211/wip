# Test levels: what goes where

| Level | Proves | Tools | Speed | Share |
|---|---|---|---|---|
| Unit | Pure logic, validators, utils, services with mocked deps | Jest/Vitest | ms | ~60-70% |
| Component | UI states and interactions in isolation | Testing Library + Vitest/Jest | tens of ms | ~15-20% |
| API / integration | Route handler + validation + auth + DB (test DB) | supertest / direct handler calls | 100s of ms | ~10-15% |
| E2E | Critical user journeys across the stack | Playwright | seconds | ≤5-10% |

## Choosing the level
- Business rule or calculation? → unit.
- "Shows error when…/disables button while…"? → component.
- Auth, permissions, status codes, persistence? → API/integration.
- "User can sign up and place an order"? → E2E (happy path + 1-2 key failures only).

## What to cover per AC
Happy path · validation failure · permission denied · not found · boundary values · empty/large data · dependency failure (mocked) · idempotency/duplicate where relevant.

## Mock policy
- Mock: network, time, randomness, email/payment/3rd-party SDKs.
- Keep real: your own validation, pure logic, DB (use a test DB/in-memory/containers) for integration tests.

## Flakiness checklist
Fixed sleeps · shared state between tests · real clock/network · order dependence · animations · unawaited promises · non-unique test data.
