// API/integration test template: call the route handler directly (no server needed).
// Use a test database or mock the data layer; never real data.
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { NextRequest } from 'next/server';
import { POST } from '@/app/api/products/route';

vi.mock('@/lib/auth', () => ({ getSessionUser: vi.fn() }));
import { getSessionUser } from '@/lib/auth';

const req = (body: unknown) =>
  new NextRequest('http://localhost/api/products', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });

describe('POST /api/products (REQ-001)', () => {
  beforeEach(() => vi.mocked(getSessionUser).mockResolvedValue({ id: 'u1', role: 'admin' }));

  it('TC-020 returns 201 for valid input (AC-001)', async () => {
    const res = await POST(req({ name: 'Demo Mug', price: 9.9 }));
    expect(res.status).toBe(201);
    expect((await res.json()).data).toMatchObject({ name: 'Demo Mug' });
  });

  it('TC-021 returns 400 with an error shape for invalid input (AC-002)', async () => {
    const res = await POST(req({ name: '', price: -1 }));
    expect(res.status).toBe(400);
    expect((await res.json()).error).toHaveProperty('message');
  });

  it('TC-022 returns 401 when not logged in (AC-003)', async () => {
    vi.mocked(getSessionUser).mockResolvedValue(null);
    expect((await POST(req({ name: 'x', price: 1 }))).status).toBe(401);
  });
});
