// Component test template (React Testing Library + Vitest/Jest). Query by role/label like a user would.
import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ProductForm } from '@/components/products/ProductForm';

describe('ProductForm (REQ-001)', () => {
  it('TC-010 shows a validation error and does not submit when name is empty (AC-002)', async () => {
    const onSubmit = vi.fn();
    render(<ProductForm onSubmit={onSubmit} />);

    await userEvent.click(screen.getByRole('button', { name: /create product/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent(/name is required/i);
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it('TC-011 disables the submit button while pending', async () => {
    render(<ProductForm onSubmit={() => new Promise(() => {})} />);

    await userEvent.type(screen.getByLabelText(/name/i), 'Demo Mug');
    await userEvent.click(screen.getByRole('button', { name: /create product/i }));

    expect(screen.getByRole('button', { name: /creating/i })).toBeDisabled();
  });
});
