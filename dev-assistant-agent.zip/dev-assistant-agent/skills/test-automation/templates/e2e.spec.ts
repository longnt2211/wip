// E2E template (Playwright). Few, critical journeys. Auto-waiting assertions; no fixed sleeps.
import { test, expect } from '@playwright/test';

test.describe('Create product journey (REQ-001)', () => {
  // Prefer logging in via API/storageState (configured in playwright.config) over the UI each time.

  test('TC-030 user can create a product and see it in the list (AC-001)', async ({ page }) => {
    await page.goto('/products/new');

    await page.getByLabel('Name').fill('Demo Mug');
    await page.getByLabel('Price').fill('9.90');
    await page.getByRole('button', { name: 'Create product' }).click();

    await expect(page).toHaveURL(/\/products$/);
    await expect(page.getByRole('link', { name: 'Demo Mug' })).toBeVisible();
  });

  test('TC-031 shows an inline error when name is empty (AC-002)', async ({ page }) => {
    await page.goto('/products/new');
    await page.getByRole('button', { name: 'Create product' }).click();
    await expect(page.getByRole('alert')).toContainText(/name is required/i);
  });
});
