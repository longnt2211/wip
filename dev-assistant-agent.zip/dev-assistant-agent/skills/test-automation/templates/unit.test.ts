// Unit test template (Vitest syntax; Jest is the same except for the import and vi -> jest).
// Replace names/paths. Keep the TC id in the test title for traceability.
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { createProduct } from '@/lib/products/service';

describe('createProduct (REQ-001)', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-01-01T00:00:00Z'));
  });
  afterEach(() => {
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  it('TC-001 creates a product with valid input (AC-001)', async () => {
    const repo = { insert: vi.fn().mockResolvedValue({ id: 1, name: 'Demo Mug', price: 9.9 }) };

    const result = await createProduct({ name: 'Demo Mug', price: 9.9 }, repo);

    expect(repo.insert).toHaveBeenCalledWith(expect.objectContaining({ name: 'Demo Mug' }));
    expect(result).toEqual({ id: 1, name: 'Demo Mug', price: 9.9 });
  });

  it('TC-002 rejects an empty name (AC-002)', async () => {
    const repo = { insert: vi.fn() };

    await expect(createProduct({ name: '', price: 9.9 }, repo)).rejects.toThrow(/name/i);
    expect(repo.insert).not.toHaveBeenCalled();
  });
});
