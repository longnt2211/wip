---
name: uiux-audit-improve
description: "Use when: auditing the UI/UX of a Next.js web app and producing improvement suggestions. Runs 3 phases: (1) verify source (routes, components, states, a11y smells), (2) verify UI/UX by rendering pages to human-viewable static HTML with dummy data (and screenshots when possible), (3) export a Markdown audit report plus an HTML before/after demo. Triggers on 'audit UI/UX', 'review user experience', 'improve usability', 'make the UI more engaging/comfortable', 'UX report', 'accessibility review of Next.js pages'."
---

# UI/UX Audit & Improve (Next.js)

Audit how users interact with a Next.js app, then deliver concrete, prioritized suggestions to make it more engaging and comfortable to use.

**Deliverables** (written to `uiux-audit/` in the target project unless the user says otherwise):

| File | Purpose |
|------|---------|
| `uiux-audit/report.md` | Findings, severity, evidence, suggested fixes, quick-win list |
| `uiux-audit/demo/index.html` | Human-viewable demo: page snapshots (with dummy data) and before/after proposals |
| `uiux-audit/source-inventory.json` | Output of the source scan (routes, states, smells) |
| `uiux-audit/snapshots/*.html` (+ `*.png` when a browser is available) | Per-page static renders |

## Reference files (read only what you need)

| File | Read when |
|------|-----------|
| [references/audit-checklist.md](./references/audit-checklist.md) | Phase 2: criteria, severity scale, what to look for per page type |
| [references/nextjs-to-html.md](./references/nextjs-to-html.md) | Phase 2: choosing a method to turn pages into viewable HTML with dummy data |
| [references/report-template.md](./references/report-template.md) | Phase 3: structure of `report.md` and the finding format |
| [templates/demo-template.html](./templates/demo-template.html) | Phase 3: starting point for `demo/index.html` |
| [scripts/scan-nextjs.mjs](./scripts/scan-nextjs.mjs) | Phase 1: automated source inventory |

## Ground rules

1. **Audit is read-only for app code.** Never modify the app's source. Write only under `uiux-audit/` (and temporary mock files you delete afterward). Proposed changes go in the report/demo as snippets.
2. **Never use real data or secrets.** Use dummy data only. Don't read `.env*` values or paste tokens into outputs. Don't call production APIs.
3. **Evidence over opinion.** Every finding cites a file/line, a page route, or a screenshot/snapshot, and names the user impact.
4. **Prioritize.** Each finding gets severity (Critical/Major/Minor/Polish) and effort (S/M/L). Lead the report with the top 5 quick wins (high impact, small effort).
5. **Respect existing design system.** Suggestions should use the project's UI kit/Tailwind tokens/components where they exist.
6. **State uncertainty.** If a page could not be rendered or a state was not observed, say so in the report rather than guessing.

## Phase 0: Scope (brief)

Ask only if unclear (use ask_user): target app path, which user flows matter most (e.g. sign-up, checkout), target audience/devices, and whether a dev server may be started. Otherwise default to: all routes, desktop + mobile (375px), no server start required.

## Phase 1: Verify source

1. Confirm it's Next.js: `package.json` has `next`; note version, router type (`app/` vs `pages/`), styling (Tailwind/CSS modules/UI lib), form/data libs, auth, i18n.
2. Run the scanner (Node 18+, no dependencies):
   ```bash
   node <skill-dir>/scripts/scan-nextjs.mjs <app-root> --out uiux-audit/source-inventory.json
   ```
   It lists routes, layouts, `loading`/`error`/`not-found` coverage, client vs server components, forms, images, buttons/links/inputs, and heuristic a11y/UX smells with file:line.
3. Read the key files the scan points to: root layout, navigation, 2-3 main pages, and any shared form/button/modal components.
4. Build a **flow map**: for each important user journey, list the routes and actions in order (e.g. `/login → /products → /products/new → submit → /products/[id]`).
5. Record gaps: missing `loading.tsx`/`error.tsx`/`not-found.tsx`, no empty state, no validation messages, no focus styles, hard-coded colors with low contrast, unlabeled inputs, `<img>` without `alt`, click handlers on `div`, etc.

## Phase 2: Verify UI/UX

Goal: let a human (and you) *see* each page with realistic dummy content.

1. Pick a method from [references/nextjs-to-html.md](./references/nextjs-to-html.md), in this order of preference:
   - **A. Live render + snapshot**: run the app with mocked data and capture HTML/screenshots (best fidelity).
   - **B. Static export of mocked pages**: render pages via `next build` + `output: 'export'` in a temp copy, with mock fetch layer.
   - **C. Hand-built static HTML**: convert JSX to HTML by hand using the project's compiled CSS and dummy data (fallback when the app can't run: DB/auth required).
2. Create dummy data that exercises states: normal, long text, empty list, one item, many items, error, loading, validation failure.
3. Save each page to `uiux-audit/snapshots/<route-slug>.html` (self-contained: inline or relative CSS, no external API calls). Take mobile and desktop screenshots when a browser tool is available.
4. Evaluate every page and flow against [references/audit-checklist.md](./references/audit-checklist.md): clarity, navigation, feedback, forms, visual hierarchy, consistency, accessibility, responsiveness, performance perception, microcopy, and delight/engagement.
5. Note findings as you go in the finding format from the report template.

## Phase 3: Export

1. Write `uiux-audit/report.md` following [references/report-template.md](./references/report-template.md): summary, scorecard, quick wins, findings by page/flow, proposed content/microcopy, accessibility, roadmap.
2. Build `uiux-audit/demo/index.html` from [templates/demo-template.html](./templates/demo-template.html): a single self-contained page with a nav of audited pages, the snapshot (iframe or screenshot), numbered findings, and **before/after** proposals (render the improved markup with dummy data where feasible).
3. Validate outputs:
   - Open `demo/index.html` (browser tool or `Start-Process`) and confirm snapshots load and links work (relative paths).
   - Every finding in `report.md` has an ID, severity, evidence and fix; IDs referenced in the demo exist in the report.
   - No secrets/real data present (`grep` for `token`, `secret`, `@` emails from real users).
4. Clean up temporary mock files/servers you created. Tell the user where the files are, the top quick wins, and anything that couldn't be verified.

## Suggestion principles (what "better" means)

- **Comfort**: fewer steps, clear next action, forgiving forms, readable type (≥16px body, 4.5:1 contrast), touch targets ≥44px, generous spacing.
- **Interest/engagement**: purposeful microcopy, skeleton loaders instead of spinners, optimistic updates, helpful empty states with a call to action, subtle transitions (≤200ms, respect `prefers-reduced-motion`), progress and success feedback.
- **Trust**: consistent patterns, confirmations for destructive actions with undo, visible system status, human error messages that say how to fix.
- Prefer a few high-impact changes over a long list of nitpicks.
