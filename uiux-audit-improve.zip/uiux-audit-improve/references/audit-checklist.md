# UI/UX audit checklist

## Severity scale

| Level | Meaning | Example |
|-------|---------|---------|
| Critical | Blocks a task or excludes users | Form cannot be submitted by keyboard; no error shown on failure |
| Major | Causes confusion/errors or noticeably hurts trust | No loading feedback; destructive action without confirm |
| Minor | Friction, inconsistency | Inconsistent button labels, weak empty state |
| Polish | Delight/refinement | Transitions, illustration, nicer microcopy |

Effort: **S** (<1h, one file), **M** (a few hours, a few files), **L** (design/architecture change).
Priority = impact first, then lowest effort.

## Scorecard (rate 1-5 per area; justify each)

Clarity · Navigation · Feedback & system status · Forms & input · Visual hierarchy · Consistency · Accessibility · Responsiveness · Perceived performance · Microcopy & tone · Engagement/delight

## 1. Clarity and information hierarchy
- One primary action per screen, visually dominant.
- Headings describe content; page title/`<title>` unique per route.
- Scannable: short paragraphs, grouping, whitespace, aligned grids.
- Primary info above the fold on mobile.

## 2. Navigation and orientation
- User always knows where they are (active nav state, breadcrumbs on deep pages, back path).
- Key destinations reachable within 2 clicks.
- Logo links home; consistent header/footer; mobile menu usable.
- 404 and error pages offer a way back.

## 3. Feedback and system status
- Every async action has loading, success, and error feedback (spinner/skeleton, toast/inline message).
- Buttons disable or show progress while submitting (prevents double submit).
- Destructive actions: confirm or offer undo; say what will be deleted.
- Optimistic UI where safe; visible result after save (redirect with message or inline update).
- Next.js: `loading.tsx`, `error.tsx`, `not-found.tsx`, `Suspense` boundaries present for data routes.

## 4. Forms and input
- Visible `<label>` for every input (placeholder is not a label); correct `type`, `autocomplete`, `inputmode`.
- Inline validation on blur/submit with specific, fixable messages; keep entered values on error; focus first invalid field.
- Mark required/optional consistently; show format hints before errors.
- Password: show/hide toggle, rules visible up front.
- Sensible defaults; avoid unnecessary fields; long forms split into steps with progress.
- Submit button label states the action ("Create product", not "Submit").

## 5. Lists, tables, search
- Empty state: explain why empty + primary action. No-results state: suggest clearing filters.
- Pagination/infinite scroll with count and position; stable sort and filter controls.
- Search: debounce, clear button, preserves query in URL, highlights match, handles zero results.
- Dense data: sticky header, responsive handling (cards or horizontal scroll with cue).

## 6. Visual design and consistency
- Spacing/typography scale used consistently (Tailwind tokens, not ad-hoc values).
- Limited palette; color is not the only signal (add icon/text for status).
- Buttons: consistent hierarchy (primary/secondary/tertiary/destructive) and sizes.
- Consistent terminology (e.g. "Product" vs "Item"), casing, date/number/currency formats.

## 7. Accessibility (WCAG 2.2 AA essentials)
- Contrast: text 4.5:1 (large 3:1), UI components/focus 3:1.
- Keyboard: all interactive elements reachable, logical tab order, visible `:focus-visible`, no keyboard traps, skip link.
- Semantics: real `<button>`/`<a>`, landmarks (`header/nav/main/footer`), one `<h1>`, heading order, lists/tables used correctly.
- Names: `alt` on informative images (empty `alt=""` for decorative), `aria-label` on icon-only buttons, labels tied to inputs (`htmlFor`/`id`).
- Dynamic content: errors/toasts announced (`role="alert"`/`aria-live`), modals trap/restore focus and close on Esc.
- Touch targets ≥24px minimum, ≥44px recommended; no hover-only information.
- Motion: respect `prefers-reduced-motion`; no auto-playing content without control.
- `lang` on `<html>`; zoom to 200% without loss.

## 8. Responsiveness
- Test 375, 768, 1280px: no horizontal scroll, readable type, tap-friendly controls, collapsed nav works.
- Images constrained and sized (`next/image` with `sizes`); tables adapt.
- Sticky/fixed elements don't cover content or inputs when the mobile keyboard opens.

## 9. Perceived performance
- Skeletons/placeholders instead of blank screens; avoid layout shift (set image dimensions, reserve space).
- Above-the-fold image priority (`priority`), fonts via `next/font`, lazy-load the rest.
- Heavy client components split with `dynamic()`; prefer server components for static content.
- Smooth transitions between routes (prefetch via `Link`).

## 10. Microcopy and tone
- Plain language, active voice, specific verbs; consistent tone.
- Error messages: what happened + how to fix, no blame/jargon/codes only.
- Empty/success states are encouraging, short, and actionable.
- Confirmations name the object ("Delete 'Blue Mug'?").

## 11. Engagement and delight (use sparingly)
- Clear first-run experience/onboarding hints; progress indicators; quick wins early.
- Meaningful micro-interactions (button press, success check, list item enter) ≤200ms.
- Personalization where cheap (greeting, recent items, saved filters).
- Visual warmth: illustrations/icons for empty and success states; consistent imagery.
- Shortcuts for power users (keyboard shortcuts, remembered preferences).

## Page-type quick checks

| Page | Must check |
|------|-----------|
| Landing/home | Value proposition in 5s, single primary CTA, social proof, mobile hero |
| Login/register | Labels, show password, errors, social login order, forgot-password link, redirect after login |
| List/catalog | Empty/loading/error, filters, pagination, card clarity, price/status prominence |
| Detail | Primary action visible, breadcrumbs, related items, image gallery |
| Create/edit form | Validation, unsaved-changes warning, cancel path, success feedback |
| Dashboard | Most important metric first, actionable widgets, empty widgets |
| Settings/profile | Grouped sections, save feedback, destructive zone separated |
| 404/500 | Friendly message, search/home link, retry |

## Heuristic cross-reference (Nielsen)
Visibility of status · Match with real world · User control & freedom · Consistency & standards · Error prevention · Recognition over recall · Flexibility & efficiency · Aesthetic & minimalist design · Help users recover from errors · Help & documentation.
