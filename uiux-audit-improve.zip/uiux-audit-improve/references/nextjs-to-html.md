# Turning Next.js pages into human-viewable HTML with dummy data

Goal: for each route, produce a self-contained `uiux-audit/snapshots/<slug>.html` (and optional PNG) filled with realistic **dummy data**, without touching real services.

Never edit the app in place. Work in a temp copy (e.g. `uiux-audit/.work/app-copy`, excluding `node_modules`, `.next`, `.env*`) or use env/flag-based mocking that you remove afterwards.

## Choose a method

| Method | Use when | Fidelity | Effort |
|--------|----------|----------|--------|
| A. Live render + snapshot | App runs locally; data/auth can be mocked | Highest | Medium |
| B. Static export of a mocked copy | Pages are mostly static/mockable; want portable HTML | High | Medium |
| C. Hand-built static HTML | App can't run (needs DB/OAuth/etc.) or time is short | Medium | Low-Medium |

## Common first step: dummy data

Create `uiux-audit/mock/data.json` (or `.ts`) from the app's types/schemas (`types/`, Prisma schema, zod schemas, API route shapes). Include variants:

- `normal`: 6-12 realistic items (names, prices, dates, avatars via placeholder shapes)
- `long`: very long titles/descriptions/unbroken strings (tests overflow)
- `empty`: `[]`
- `single`: 1 item
- `error`: failing response
- `loading`: never-resolving or delayed response
- `invalid`: form payloads that fail validation

Use fake names/emails (`user@example.com`), placeholder images (inline SVG or `https://placehold.co/...` replaced by local files to keep snapshots offline).

## Method A: Live render + snapshot

1. Copy the project to a temp dir; install deps (`npm ci`) only if needed.
2. Mock data access so no real backend/DB is called. Options (pick the least invasive):
   - **Route handler stubs**: replace `app/api/**/route.ts` in the copy with handlers returning `mock/data.json`.
   - **Data-layer stub**: replace the module that wraps DB/fetch (`lib/db`, `lib/api`, repository) with an in-memory mock.
   - **MSW / fetch override** for client-side fetches.
   - **Auth bypass** in the copy: stub `getServerSession`/`useSession`/middleware to return a fake user (`{ name: 'Demo User', email: 'demo@example.com' }`). Make a variant without session to capture logged-out pages.
3. Start the dev server on a free port (`npx next dev -p 3999`) as an async process; verify with `curl http://localhost:3999/`.
4. Capture each route:
   - **Browser tools available** (Playwright/browser MCP tools): navigate, set viewport 1280x800 and 375x812, take screenshots, and save the rendered DOM (`document.documentElement.outerHTML`).
   - **No browser tool**: `curl -s http://localhost:3999/<route> -o snapshot.html` gives the server-rendered HTML (client-only content may be missing; note this in the report).
   - Playwright script alternative (if `playwright` is installed):
     ```js
     import { chromium } from 'playwright';
     const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1280, height: 800 } });
     await p.goto('http://localhost:3999/products'); await p.waitForLoadState('networkidle');
     await p.screenshot({ path: 'snapshots/products-desktop.png', fullPage: true });
     require('fs').writeFileSync('snapshots/products.html', await p.content());
     ```
5. Make snapshots offline-friendly: inline the CSS (`<link rel=stylesheet>` → `<style>` with contents from `.next/static/css/*.css` or fetched from the dev server), remove `<script>` tags (static view) and rewrite image URLs to local files or data URIs.
6. Interact for states: type invalid input and submit; trigger empty search; toggle mobile menu; capture each as its own snapshot (`login-error.html`, `products-empty.html`).
7. Stop the server (`Stop-Process -Id <pid>`) and delete the temp copy.

## Method B: Static export of a mocked copy

1. In the temp copy set `next.config.js`: `output: 'export'`, `images: { unoptimized: true }`.
2. Replace data access with mocks (as above) so pages render at build time; convert dynamic routes to `generateStaticParams()` returning mock ids; drop/stub route handlers and middleware (not supported in export).
3. `npx next build` → `out/` contains HTML + CSS for each route. Copy to `uiux-audit/snapshots/` (adjust asset paths to relative; `basePath`/`assetPrefix: '.'` can help).
4. Client-only interactions won't be captured; document states by adding variants (e.g. `/products?state=empty` implemented via mock switch).

## Method C: Hand-built static HTML (fallback)

1. Read the page's JSX (server component and children) and write equivalent HTML manually: replace `className` → `class`, `htmlFor` → `for`, self-close void tags, expand `.map()` over the dummy data, resolve conditionals for each state, replace `<Link>` with `<a>`, `<Image>` with `<img>`.
2. Styling:
   - Tailwind: build CSS from the original config for just these files: `npx tailwindcss -c tailwind.config.ts -i app/globals.css -o uiux-audit/snapshots/styles.css --content "uiux-audit/snapshots/*.html"`; or use the Tailwind CDN script in the snapshot (acceptable for a demo; say so).
   - CSS modules/other: copy the relevant CSS and class names, or inline the compiled CSS from `.next/static/css` if a build exists.
3. Wrap each page in the real layout markup (header/nav/footer) so context is accurate.
4. Mark clearly at the top of each snapshot: `<!-- Static reproduction with dummy data; not the live app -->` and add a small banner variable in the demo so reviewers know it's an approximation.

## Snapshot hygiene

- File naming: route → slug (`/products/[id]` → `products-id`, `/` → `home`) plus state/viewport suffix (`-empty`, `-mobile`).
- Self-contained: relative paths only; works by double-clicking the file.
- No real data, tokens, cookies or internal URLs. Strip `<meta>` containing CSRF tokens and `__NEXT_DATA__` payloads with real values.
- Keep a `snapshots/index.json` mapping `route → files → state/viewport → method (A/B/C)` for the demo and report.

## What to do when rendering fails

Report it. State which routes were only reviewed from source, why (DB, OAuth, env), and lower confidence on visual findings for those pages. Offer Method C for them rather than skipping silently.
