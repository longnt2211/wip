# Report template (`uiux-audit/report.md`)

Write in the user's language (default: match the language they used). Keep it scannable. Use this structure.

````markdown
# UI/UX Audit: <App name>

- **Date**: YYYY-MM-DD
- **Scope**: <routes/flows audited>, devices: desktop 1280px + mobile 375px
- **Method**: source review + <A live render | B static export | C hand-built HTML> with dummy data
- **Not verified**: <routes/states not rendered and why>

## 1. Executive summary
3-5 sentences: overall impression, biggest risks, biggest opportunities.

## 2. Scorecard
| Area | Score (1-5) | Note |
|------|-------------|------|
| Clarity | | |
| Navigation | | |
| Feedback & status | | |
| Forms & input | | |
| Visual hierarchy | | |
| Consistency | | |
| Accessibility | | |
| Responsiveness | | |
| Perceived performance | | |
| Microcopy | | |
| Engagement | | |

## 3. Top quick wins (high impact, small effort)
1. **F-003**: <one line> (S)
2. ...

## 4. User flows reviewed
| Flow | Steps | Friction found |
|------|-------|----------------|
| Sign up → first product | `/register` → `/login` → `/products/new` | F-001, F-004 |

## 5. Findings
(group by page or flow; one block per finding)

### F-001 [Major | Effort S] Login form gives no error feedback
- **Where**: `/login` · `app/login/page.tsx:42` · snapshot `snapshots/login-error.html`
- **Observed**: <what happens, with dummy-data scenario>
- **User impact**: <who is affected and how>
- **Heuristic/Criterion**: Feedback & status; WCAG 3.3.1
- **Recommendation**: <specific change>
- **Suggested content**: "<new microcopy / label / empty-state text>"
- **Code sketch** (optional):
  ```tsx
  <p role="alert" className="text-sm text-red-700">Email or password is incorrect. Try again or reset your password.</p>
  ```
- **Demo**: `demo/index.html#F-001`

## 6. Content suggestions (microcopy and states)
| Location | Current | Proposed | Why |
|----------|---------|----------|-----|
| Products empty state | (blank) | "No products yet. Add your first product to get started." + [Add product] | Guides next step |

## 7. Accessibility summary
Contrast, keyboard, semantics, announcements: what passes, what fails, with finding IDs.

## 8. Roadmap
| Phase | Items | Rationale |
|-------|-------|-----------|
| Now (1-2 days) | F-003, F-007 | Quick wins |
| Next (1-2 weeks) | F-001, F-005 | Major friction |
| Later | F-010 | Larger redesign |

## 9. Appendix
- Source inventory: `source-inventory.json`
- Snapshot index: `snapshots/index.json`
- Dummy data used: `mock/data.json` (if kept)
- Assumptions and limitations
````

## Finding quality bar

- **Specific**: names the element, route and file; no "improve the design".
- **Actionable**: a developer can implement it without asking questions; include the proposed text/markup.
- **Evidenced**: source line, snapshot, or screenshot.
- **Impact-stated**: who struggles and why.
- **Unique IDs** `F-001…` used consistently in the report and demo.
- Cap at ~25 findings; merge duplicates and mention "also affects" routes.
- Include at least a few **positive observations** (what works well and should be kept).
