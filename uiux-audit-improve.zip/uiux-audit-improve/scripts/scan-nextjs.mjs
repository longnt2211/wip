#!/usr/bin/env node
// Dependency-free Next.js source scanner for UI/UX audits (read-only).
// Usage: node scan-nextjs.mjs <app-root> [--out inventory.json]

import { readdirSync, readFileSync, statSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { join, relative, extname, dirname, sep } from 'node:path';

const args = process.argv.slice(2);
const root = args.find((a) => !a.startsWith('--'));
const outIdx = args.indexOf('--out');
const outFile = outIdx >= 0 ? args[outIdx + 1] : null;
if (!root || !existsSync(root)) {
  console.error('Usage: node scan-nextjs.mjs <app-root> [--out inventory.json]');
  process.exit(1);
}

const SKIP = new Set(['node_modules', '.next', '.git', 'out', 'dist', 'build', 'coverage', 'uiux-audit']);
const EXT = new Set(['.tsx', '.jsx', '.ts', '.js', '.mjs']);
const SPECIAL = ['layout', 'page', 'loading', 'error', 'not-found', 'template', 'global-error', 'route', 'default'];

function walk(dir, acc = []) {
  for (const name of readdirSync(dir)) {
    if (SKIP.has(name)) continue;
    const p = join(dir, name);
    const s = statSync(p);
    if (s.isDirectory()) walk(p, acc);
    else if (EXT.has(extname(name))) acc.push(p);
  }
  return acc;
}

const posix = (p) => p.split(sep).join('/');
const lineOf = (text, index) => text.slice(0, index).split('\n').length;

// Returns [{ tag, attrs, start, end }] for opening tags, honoring {} nesting in JSX attributes.
function openingTags(text, names) {
  const out = [];
  const re = new RegExp(`<(${names.join('|')})(?=[\\s/>])`, 'g');
  let m;
  while ((m = re.exec(text))) {
    let i = m.index + m[0].length, depth = 0, quote = null;
    for (; i < text.length; i++) {
      const c = text[i];
      if (quote) { if (c === quote) quote = null; continue; }
      if (depth === 0 && (c === '"' || c === "'")) { quote = c; continue; }
      if (c === '{') depth++;
      else if (c === '}') depth--;
      else if (c === '>' && depth === 0) break;
    }
    out.push({ tag: m[1], attrs: text.slice(m.index + m[0].length, i), start: m.index, end: i + 1 });
  }
  return out;
}

const has = (attrs, name) => new RegExp(`(^|\\s)${name}(\\s*=|\\s|/|$)`).test(attrs);
const classOf = (attrs) => (attrs.match(/className\s*=\s*(?:"([^"]*)"|\{`([^`]*)`\}|\{"([^"]*)"\}|'([^']*)')/s) || []).slice(1).find(Boolean) || '';

const files = walk(root);
const appDirRel = ['app', 'src/app'].find((d) => existsSync(join(root, d)));
const pagesDirRel = ['pages', 'src/pages'].find((d) => existsSync(join(root, d)));

const pkg = existsSync(join(root, 'package.json')) ? JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')) : {};
const deps = { ...pkg.dependencies, ...pkg.devDependencies };
const stack = {
  next: deps.next || null,
  react: deps.react || null,
  router: appDirRel ? 'app' : pagesDirRel ? 'pages' : 'unknown',
  tailwind: !!deps.tailwindcss,
  uiLibs: ['@mui/material', '@chakra-ui/react', 'antd', '@radix-ui/react-dialog', 'shadcn-ui', '@headlessui/react', 'daisyui', 'react-bootstrap']
    .filter((d) => deps[d]),
  forms: ['react-hook-form', 'formik', 'zod', 'yup', '@hookform/resolvers'].filter((d) => deps[d]),
  data: ['@tanstack/react-query', 'swr', 'axios', 'zustand', 'redux', '@reduxjs/toolkit'].filter((d) => deps[d]),
  auth: ['next-auth', '@auth/core', '@clerk/nextjs', '@supabase/auth-helpers-nextjs'].filter((d) => deps[d]),
  animation: ['framer-motion', 'motion'].filter((d) => deps[d]),
  i18n: ['next-intl', 'next-i18next', 'react-i18next'].filter((d) => deps[d]),
};

const routes = [];
const special = {};
const components = [];
const smells = [];
const totals = { forms: 0, inputs: 0, buttons: 0, links: 0, images: 0, clientComponents: 0 };

function smell(file, text, index, rule, severity, message) {
  smells.push({ file: posix(relative(root, file)), line: lineOf(text, index), rule, severity, message });
}

for (const file of files) {
  const rel = posix(relative(root, file));
  const base = file.split(sep).pop().replace(/\.(tsx|jsx|ts|js|mjs)$/, '');
  const text = readFileSync(file, 'utf8');
  const isUi = /\.(tsx|jsx)$/.test(file);

  // Routes and special files (app router)
  if (appDirRel && rel.startsWith(appDirRel + '/')) {
    const dirRel = posix(dirname(rel)).slice(appDirRel.length) || '';
    if (SPECIAL.includes(base)) {
      (special[dirRel || '/'] ||= []).push(base);
      if (base === 'page') {
        const url = '/' + dirRel.split('/').filter((s) => s && !/^\(.*\)$/.test(s) && !s.startsWith('@')).join('/');
        routes.push({ route: url === '/' ? '/' : url, file: rel, router: 'app' });
      }
    }
  } else if (pagesDirRel && rel.startsWith(pagesDirRel + '/') && !rel.includes('/api/') && /\.(tsx|jsx)$/.test(file)) {
    const r = '/' + rel.slice(pagesDirRel.length + 1).replace(/\.(tsx|jsx)$/, '').replace(/\/index$/, '').replace(/^index$/, '');
    if (!/^\/_/.test(r)) routes.push({ route: r || '/', file: rel, router: 'pages' });
  }

  if (!isUi || base === 'route') continue;

  const isClient = /^\s*(?:\/\/.*\n|\/\*[\s\S]*?\*\/\s*)*['"]use client['"]/.test(text);
  if (isClient) totals.clientComponents++;
  components.push({ file: rel, client: isClient, lines: text.split('\n').length });

  const tags = openingTags(text, ['form', 'input', 'textarea', 'select', 'button', 'a', 'Link', 'img', 'Image', 'div', 'span', 'html', 'h1']);
  const count = (names) => tags.filter((t) => names.includes(t.tag)).length;
  totals.forms += count(['form']);
  totals.inputs += count(['input', 'textarea', 'select']);
  totals.buttons += count(['button']);
  totals.links += count(['a', 'Link']);
  totals.images += count(['img', 'Image']);

  for (const t of tags) {
    const cls = classOf(t.attrs);
    if ((t.tag === 'img' || t.tag === 'Image') && !has(t.attrs, 'alt'))
      smell(file, text, t.start, 'img-alt', 'major', `<${t.tag}> without alt text`);
    if (['input', 'textarea', 'select'].includes(t.tag) && !/type\s*=\s*["']hidden["']/.test(t.attrs) &&
        !has(t.attrs, 'aria-label') && !has(t.attrs, 'aria-labelledby') && !has(t.attrs, 'id') && !/\{\.\.\./.test(t.attrs))
      smell(file, text, t.start, 'input-label', 'major', `<${t.tag}> has no id/aria-label (label association unlikely)`);
    if (['input', 'textarea'].includes(t.tag) && has(t.attrs, 'placeholder') && !has(t.attrs, 'aria-label') && !has(t.attrs, 'id'))
      smell(file, text, t.start, 'placeholder-as-label', 'minor', 'placeholder may be the only label');
    if (t.tag === 'button') {
      const close = text.indexOf('</button>', t.end);
      const inner = close > -1 ? text.slice(t.end, close) : '';
      const visible = inner.replace(/\{[^}]*\}/g, (m) => (/['"`][^'"`]+['"`]/.test(m) ? 'x' : '')).replace(/<[^>]*>/g, '').trim();
      if (!visible && !has(t.attrs, 'aria-label') && !has(t.attrs, 'aria-labelledby') && !has(t.attrs, 'title'))
        smell(file, text, t.start, 'icon-button-name', 'major', 'icon-only <button> without aria-label');
    }
    if ((t.tag === 'div' || t.tag === 'span') && has(t.attrs, 'onClick') && !has(t.attrs, 'role'))
      smell(file, text, t.start, 'click-on-non-interactive', 'major', `onClick on <${t.tag}> (not keyboard accessible); use <button>/<a>`);
    if (t.tag === 'a' && /href\s*=\s*["']#?["']/.test(t.attrs))
      smell(file, text, t.start, 'dead-link', 'minor', '<a> with empty or "#" href');
    if ((t.tag === 'a' || t.tag === 'Link') && /target\s*=\s*["']_blank["']/.test(t.attrs) && !/rel\s*=\s*["'][^"']*noopener/.test(t.attrs))
      smell(file, text, t.start, 'blank-no-rel', 'minor', 'target="_blank" without rel="noopener noreferrer"');
    if (/\boutline-none\b/.test(cls) && !/focus(-visible|-within)?:/.test(cls))
      smell(file, text, t.start, 'focus-removed', 'major', 'outline-none without a focus:/focus-visible: replacement');
    if (/\btext-(gray|slate|zinc|neutral)-(300|400)\b/.test(cls))
      smell(file, text, t.start, 'low-contrast', 'minor', 'light gray text (verify contrast >= 4.5:1)');
    if (t.tag === 'html' && !has(t.attrs, 'lang'))
      smell(file, text, t.start, 'html-lang', 'major', '<html> without lang');
  }

  if (/\b(window\.)?(alert|confirm|prompt)\(/.test(text)) {
    const m = text.match(/\b(window\.)?(alert|confirm|prompt)\(/);
    smell(file, text, m.index, 'native-dialog', 'minor', `native ${m[2]}() dialog; consider an in-page dialog/toast`);
  }
  const asyncUse = /\bfetch\(|useMutation|axios\.|signIn\(|router\.push/.test(text) && isClient;
  if (asyncUse && !/isLoading|isPending|loading|submitting|isSubmitting|disabled/.test(text))
    smell(file, text, 0, 'no-loading-state', 'major', 'client async action without visible loading/disabled state');
  if (asyncUse && !/error|catch|isError|onError/i.test(text))
    smell(file, text, 0, 'no-error-state', 'major', 'client async action without error handling/feedback');
  // Only JSX-rendering maps (`{x.map(... => (<` or `=> <`), and not when an empty check exists
  const jsxMap = text.match(/\{[\w.?\[\]]+\.map\(\s*\(?[\w\s,{}]*\)?\s*=>\s*\(?\s*</);
  if (jsxMap && !/length\s*===?\s*0|!\w+\.length|\.length\s*\?|\.length\s*&&|empty|No \w+ (found|yet)/i.test(text))
    smell(file, text, jsxMap.index, 'no-empty-state', 'minor', 'list rendering without an obvious empty state');
  if (appDirRel && base === 'page' && count(['h1']) === 0 && !/<h1/.test(text))
    smell(file, text, 0, 'no-h1', 'minor', 'page has no <h1> in this file (may come from a child component)');
  if (appDirRel && base === 'layout' && dirname(rel) === appDirRel && !/metadata|generateMetadata/.test(text))
    smell(file, text, 0, 'no-metadata', 'minor', 'root layout has no metadata export (title/description)');
}

// Coverage of loading/error/not-found by nearest ancestor segment
function inherited(dir, name) {
  let d = dir;
  for (;;) {
    if ((special[d || '/'] || []).includes(name)) return true;
    if (!d || d === '/') return false;
    d = d.slice(0, d.lastIndexOf('/'));
  }
}
if (appDirRel) {
  for (const r of routes) {
    const dir = posix(dirname(r.file)).slice(appDirRel.length) || '/';
    r.loading = inherited(dir, 'loading');
    r.error = inherited(dir, 'error');
  }
  const rootSpecial = special['/'] || [];
  if (!rootSpecial.includes('not-found'))
    smells.push({ file: appDirRel, line: 0, rule: 'no-not-found', severity: 'minor', message: 'no app/not-found.tsx (default 404 page)' });
  if (!rootSpecial.includes('error') && !rootSpecial.includes('global-error'))
    smells.push({ file: appDirRel, line: 0, rule: 'no-error-boundary', severity: 'major', message: 'no root error.tsx/global-error.tsx' });
}

const bySeverity = smells.reduce((a, s) => ((a[s.severity] = (a[s.severity] || 0) + 1), a), {});
const byRule = smells.reduce((a, s) => ((a[s.rule] = (a[s.rule] || 0) + 1), a), {});
const inventory = {
  generatedAt: new Date().toISOString(),
  root: posix(root),
  stack,
  routes: routes.sort((a, b) => a.route.localeCompare(b.route)),
  totals,
  summary: { smells: smells.length, bySeverity, byRule },
  components,
  smells,
  note: 'Heuristic scan. Confirm each smell by reading the code; false positives are possible (e.g. labels via wrapper components).',
};

if (outFile) {
  mkdirSync(dirname(outFile) || '.', { recursive: true });
  writeFileSync(outFile, JSON.stringify(inventory, null, 2));
}

console.log(`Stack: next ${stack.next ?? '?'} | router: ${stack.router} | tailwind: ${stack.tailwind}`);
console.log(`Routes (${routes.length}):`);
for (const r of inventory.routes)
  console.log(`  ${r.route.padEnd(28)} ${r.file}${appDirRel ? `  loading:${r.loading ? 'y' : 'n'} error:${r.error ? 'y' : 'n'}` : ''}`);
console.log(`Totals: ${JSON.stringify(totals)}`);
console.log(`Smells: ${smells.length} ${JSON.stringify(bySeverity)}`);
console.log(`By rule: ${JSON.stringify(byRule)}`);
if (outFile) console.log(`Wrote ${outFile}`);
