---
name: web-to-html-static
description: "Use when: the user copied HTML from a web page open in the browser (DevTools outerHTML, 'Save as', pasted markup, or a file) and wants a static, self-contained HTML demo that works without any API, database, login or JavaScript framework. Converts the copied page (e.g. a rendered Next.js/React page) into static HTML: strips scripts/hydration, fixes CSS/image/link paths, redacts personal data, and fills API-driven areas (lists, tables, cards, skeletons, empty states) with realistic dummy data. Triggers on 'convert this page to static html', 'make a demo without API', 'html demo from copied page', 'mock data demo', 'offline demo of my web page'."
---

# Web page → static HTML demo

Turn HTML copied from a browser into a static page that anyone can open by double-clicking (`file://`), with dummy data instead of API/DB data.

**Output** (default `static-demo/`, ask the user if they want another folder):

| File | Purpose |
|------|---------|
| `<name>.html` | Static page (no framework scripts, no API calls) |
| `assets/` | Local copies of CSS-referenced images/fonts (when resolvable) |
| `pages.json` | Route → file map used to link pages together |
| `<name>.analysis.json` | What was removed/redacted, API endpoints seen, data regions needing dummy data |

## Reference files (read only what you need)

| File | Read when |
|------|-----------|
| [references/capture-guide.md](./references/capture-guide.md) | The user asks how to copy the HTML, or the input looks un-rendered/incomplete |
| [references/dummy-data.md](./references/dummy-data.md) | Step 3: filling lists/tables/cards/forms with dummy data, adding light interactions |
| [scripts/html-to-static.mjs](./scripts/html-to-static.mjs) | Step 2: the converter (Node 18+, no dependencies) |

## Ground rules

1. **Dummy data only.** Never call the real API/DB, never reuse the user's real records, emails, names, tokens or cookies. Replace them with obviously fake but realistic values (`user1@example.com`, "Acme Demo Co.").
2. **The output must be API-free**: no `fetch`/`XMLHttpRequest`/`axios`, no `<script src>` of framework bundles. A tiny inline vanilla-JS block for demo interactions (tabs, menus, filters) is allowed and must work offline.
3. **Keep the look identical.** Preserve markup, class names, and CSS; only swap data and fix resource paths. Don't "improve" the design unless asked.
4. **Don't modify the user's original source files or app.** Write only to the output folder; put pasted input in `<out>/_input/` (delete it at the end unless the user wants it).
5. **Be honest about fidelity**: state what could not be reproduced (client-side only behavior, auth-only views, real-time data, unresolved assets).

## Workflow

### 1. Get the input
- User pasted HTML in chat → save it with the file-create tool to `<out>/_input/<name>.html` (ask for a file path instead if it is huge).
- User gave a file path → use it directly.
- Ask (briefly, with ask_user) only for what's missing and useful: **the page URL** (gives route + asset origin), **project folder** (to resolve `public/` and `.next` assets locally), and **page name**. If the input is clearly from View Source or a bare app shell, tell the user to copy the rendered DOM instead (see capture guide).
- If browser tools are available and the user gives a URL, you may capture `document.documentElement.outerHTML` yourself.

### 2. Convert
```bash
node <skill-dir>/scripts/html-to-static.mjs convert <input.html> --out static-demo --url <page-url> [--local-root public,.next] [--download-assets] [--placeholder-images] [--tailwind-cdn]
```
- `--url` sets the route (file name derives from it) and resolves relative asset URLs; `--route /x` if there is no URL.
- `--local-root`: folders to look assets up in (Next.js: `public` and `.next`; `/_next/static/...` is mapped automatically).
- `--download-assets`: copy remote CSS/images/fonts into `assets/` so the demo works offline.
- `--placeholder-images`: swap every image for a neutral SVG (use when photos/avatars are private).
- `--tailwind-cdn`: fallback when compiled CSS cannot be found (needs internet; say so).
- Convert each captured page, then run `node <skill-dir>/scripts/html-to-static.mjs relink static-demo` so links between captured pages work. Links to pages that were not captured show a "not part of the demo" toast.

Read the printed summary and `<name>.analysis.json`: warnings (un-rendered page, skeletons, unresolved assets), `apiEndpoints`, and counts of removed scripts/redactions.

### 3. Fill in dummy data (the part the script cannot do)
Open the converted HTML and fix every data-driven region listed by `dataSignals` and your own read of the page (see [references/dummy-data.md](./references/dummy-data.md)):
- skeleton/loading blocks → real-looking content; empty lists/tables → 5-10 rows cloned from the page's own item markup;
- pages that came from a loading or error state → replace with the "happy path" view;
- numbers/dates/currency consistent with each other (totals match rows; dates in a sensible range);
- keep the page's language and tone; vary content (short/long names, mixed statuses) so the demo feels real.
Optionally add small vanilla-JS interactions (menu, tabs, modal, client-side filter/sort/search over the dummy rows) in an inline `<script data-demo>` block.

### 4. Verify
- Open the page in a browser (browser tools or `Start-Process <file>`); take a screenshot if available. Check layout, images, fonts, links between pages, and mobile width.
- `grep` the output for leftovers: `fetch(`, `/api/`, `localhost`, `eyJ`, `@` emails that aren't `example.com`, `<script src`, `__NEXT_DATA__`.
- Confirm nothing requests the network except intentional CDN assets (fonts/Tailwind) you told the user about.
- Remove `_input/` and any temp files unless requested.

### 5. Report
Give the output path(s), how to open (`static-demo/index.html`), what dummy data was invented, what was redacted, and limitations/unresolved items. Offer next steps: capture more pages, add interactions, or bundle as a zip.

## Gotchas
- React/Next `outerHTML` after hydration has the real data baked in (good). Server HTML from View Source may show skeletons/loading states (fill them in).
- Streaming Next.js pages contain hidden `<div hidden id="S:0">` + `<template>` blocks: if the visible area still shows a fallback, move the resolved content into place.
- `next/image` URLs (`/_next/image?url=...`) are unwrapped automatically; `srcset`/`sizes`/`loading=lazy` are removed so images always show.
- Inline `<style>` blocks and styled-jsx/CSS-in-JS output are kept as-is; Tailwind/CSS Modules need the compiled stylesheet (hence `--local-root` or `--url`).
- Dark mode, cookies, and locale are whatever state the copied DOM was in; mention if a toggle won't work.
- Re-running `convert` for the same route overwrites that page only; `pages.json` accumulates routes.
