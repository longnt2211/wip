# How to copy the HTML from the browser

Best input = the **rendered DOM** after the page has fully loaded, in the state you want to show (logged in, data visible, filters applied).

## Option 1: Copy outerHTML (recommended)
1. Open the page, wait until data is displayed.
2. DevTools (F12) → **Elements** tab → right-click the top `<html>` node → **Copy → Copy outerHTML**.
3. Paste into the chat (or save to a `.html` file and give the path).

## Option 2: Console one-liner (large pages)
In the DevTools Console: `copy(document.documentElement.outerHTML)` then paste. (Add `'<!DOCTYPE html>\n' +` in front if you want the doctype.)

## Option 3: Save the page
Ctrl+S → "Webpage, HTML only" (not "Complete" unless you also want the assets folder; if you do, pass that folder via `--local-root`).

## Not recommended
- **View Source** (Ctrl+U): shows server HTML before hydration; for client-rendered pages it is an empty shell or skeleton.
- Copying only `<body>`: you lose `<head>` (CSS links, title, meta). Include `<html>`.

## Tips
- Capture each state separately if the user needs more than one (e.g. list with data, empty list, form with errors) and give each a `--name`.
- Mention the page URL (e.g. `http://localhost:3000/products`): it sets the route and resolves `/_next/static/...` CSS and images.
- If the page is private/internal, say so: all personal data should be replaced; use `--placeholder-images` to hide real photos.
- Very large paste? Save to a file instead of pasting into chat.
- Dev-mode Next.js adds overlays (`<nextjs-portal>`); the converter removes them.
