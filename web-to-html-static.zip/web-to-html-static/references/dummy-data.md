# Dummy data and light interactions

The converter keeps whatever data was in the copied DOM (after redacting emails/tokens). Your job in step 3 is to make every data-driven area look real, consistent and safe.

## 1. Find data regions
Use `<name>.analysis.json` → `dataSignals` plus a read of the HTML:

| Signal | Meaning | Action |
|--------|---------|--------|
| `skeletonElements`, `ariaBusy`, `loadingText` | Page was captured while loading | Replace the skeleton blocks with the real item markup + dummy content |
| `emptyContainers` (`<ul></ul>`, `<tbody></tbody>`) | List not yet rendered / empty state | Add rows |
| `emptyAppRoot` / tiny `bodyTextLength` | Un-rendered shell | Ask for a rendered copy (capture guide) |
| `apiEndpoints` | Calls the page made (e.g. `/api/products`) | Each endpoint = a data set to invent; keep fields the UI actually shows |
| `nextData.pagePropKeys` | Server props keys | Hint at what data the page expects |
| Repeated cards/rows with real-looking personal data | Real data leaked in | Replace with fake values |

## 2. Generate dummy data
- Derive the shape from the markup (what columns/fields are shown) and from the app's types if the project is available (`types/`, zod schemas, Prisma, API route handlers).
- **5-10 items** for lists; include variety: short + long titles, different statuses/categories, one with a missing optional field, one "highlighted" (new/sale/overdue).
- Names: use clearly fictional people/companies; emails `@example.com`; phones `555-0100`-style; addresses fictional.
- Money/dates: consistent currency and locale with the page; dates within the last/next few weeks; totals = sum of rows; pagination text matches the row count.
- IDs: simple sequential (`1001`, `PRD-001`); links to detail pages use those ids.
- Images: `--placeholder-images` or inline SVG/data-URI; avoid hotlinking real photos.
- Keep language/tone of the page (Vietnamese UI → Vietnamese dummy content).

## 3. Write it into the HTML
- Clone an existing item's markup exactly (same classes, structure, aria attributes) and change only the text/attributes. Don't invent new styling.
- Replace skeleton containers rather than adding content next to them; remove `animate-pulse`, `aria-busy="true"`, and "Loading…" text.
- For a table: fill `<tbody>`; for cards: repeat the card element inside the grid; for counters/stats: set plausible numbers.
- Keep a single source of truth if the page shows the same data twice (list + detail panel, chart legend + table).

## 4. Optional light interactions (inline vanilla JS, no network)
Add one `<script data-demo>` before `</body>`. Allowed patterns:

```html
<script data-demo>
// Mobile menu / dropdown toggle
document.querySelectorAll('[data-demo-toggle]').forEach(b =>
  b.addEventListener('click', () => document.querySelector(b.dataset.demoToggle)?.classList.toggle('hidden')));

// Client-side search/filter over rendered rows
const q = document.querySelector('input[type=search], input[name=q]');
q?.addEventListener('input', () => {
  const t = q.value.toLowerCase();
  document.querySelectorAll('[data-demo-row]').forEach(r => { r.hidden = !r.textContent.toLowerCase().includes(t); });
});

// Tabs
document.querySelectorAll('[role=tab]').forEach(tab => tab.addEventListener('click', () => {
  document.querySelectorAll('[role=tab]').forEach(t => t.setAttribute('aria-selected', t === tab));
  document.querySelectorAll('[role=tabpanel]').forEach(p => p.hidden = p.id !== tab.getAttribute('aria-controls'));
}));
</script>
```
- Add `data-demo-toggle`/`data-demo-row` attributes to the markup that needs them.
- Forms are already neutralized by the injected runtime (shows "Demo mode: nothing was sent."). If the demo should show a success state, handle `submit` in your block and update the DOM (e.g. show a success message or append a row), using `e.preventDefault()`.
- Do not add `fetch`, `localStorage` of real data, timers that poll, or external scripts.
- Keep interactions minimal: only what the demo audience needs to see.

## 5. Multi-page demos
Capture each route (list, detail, form, login...) with `--url`, run `relink`, and make sure links in the dummy data point to routes that exist (e.g. `/products/1001` → capture or create that page once and reuse it for all ids, or leave a missing link: the runtime shows a toast).
