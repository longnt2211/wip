#!/usr/bin/env node
// Dependency-free converter: copied browser HTML -> static, API-free demo page.
//
//   node html-to-static.mjs convert <input.html | -> [options]
//   node html-to-static.mjs relink <out-dir>
//
// Options:
//   --out <dir>            output folder (default ./static-demo)
//   --url <page-url>       URL the HTML was copied from (gives route, origin for assets)
//   --route <path>         route for this page when --url is not given (default /)
//   --name <file-name>     output file name without .html (default derived from route)
//   --local-root <dirs>    comma-separated local folders to resolve assets from
//                          (e.g. public,.next ; "/_next/static/x" is also tried as "<root>/static/x")
//   --download-assets      download remote images/fonts/CSS into <out>/assets (offline demo)
//   --placeholder-images   replace every image with a neutral SVG placeholder (hides real photos)
//   --tailwind-cdn         add the Tailwind CDN script (when the compiled CSS is unavailable)
//   --no-redact            keep emails/tokens as-is (default: replaced with dummy values)
//   --no-banner            omit the "Static demo" badge

import { readFileSync, writeFileSync, mkdirSync, existsSync, statSync, copyFileSync, readdirSync } from 'node:fs';
import { join, basename, extname, resolve, sep } from 'node:path';
import { createHash } from 'node:crypto';

const FLAGS = new Set(['download-assets', 'placeholder-images', 'tailwind-cdn', 'no-redact', 'no-banner', 'help']);
function parseArgs(argv) {
  const o = { _: [], localRoot: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const k = a.slice(2);
      if (FLAGS.has(k)) o[k] = true;
      else {
        const v = argv[++i];
        if (k === 'local-root') o.localRoot.push(...String(v).split(',').filter(Boolean));
        else o[k] = v;
      }
    } else o._.push(a);
  }
  return o;
}

const opts = parseArgs(process.argv.slice(2));
const USAGE = `Usage:
  node html-to-static.mjs convert <input.html|-> [--out dir] [--url page-url] [--route /path] [--name file]
                           [--local-root dir,dir] [--download-assets] [--placeholder-images]
                           [--tailwind-cdn] [--no-redact] [--no-banner]
  node html-to-static.mjs relink <out-dir>`;

// ---------- small helpers ----------
const decodeEntities = (s) => s.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#x27;|&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>');
const encAttr = (s) => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;');
const escXml = (s) => s.replace(/[&<>'"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&apos;', '"': '&quot;' }[c]));
const sha = (s) => createHash('sha1').update(s).digest('hex').slice(0, 8);

const TAG_RE = /<([a-zA-Z][\w:-]*)((?:\s+[^\s"'<>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s"'=<>`]+))?)*)\s*(\/?)>/g;
const ATTR_RE = /([^\s"'<>\/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;

function parseAttrs(str) {
  const list = [];
  let m;
  ATTR_RE.lastIndex = 0;
  while ((m = ATTR_RE.exec(str))) {
    const v = m[2] ?? (m[3] !== undefined ? m[3].replace(/"/g, '&quot;') : m[4] ?? null);
    list.push({ n: m[1], v });
  }
  return list;
}
const buildAttrs = (list) => list.map((a) => (a.v === null ? ` ${a.n}` : ` ${a.n}="${a.v}"`)).join('');
const getAttr = (list, n) => list.find((a) => a.n.toLowerCase() === n)?.v;
const delAttr = (list, n) => { const i = list.findIndex((a) => a.n.toLowerCase() === n); if (i >= 0) list.splice(i, 1); };
function setAttr(list, n, v) {
  const a = list.find((x) => x.n.toLowerCase() === n);
  if (a) a.v = v; else list.push({ n, v });
}

function normRoute(p) {
  let r = (p || '/').split('#')[0].split('?')[0];
  if (!r.startsWith('/')) r = '/' + r;
  if (r.length > 1) r = r.replace(/\/+$/, '');
  return r || '/';
}
const slugOf = (route) => (route === '/' ? 'index' : route.replace(/^\/|\/$/g, '').replace(/[^\w.-]+/g, '-').replace(/-+/g, '-') || 'index');

function placeholder(w, h, label) {
  w = Math.max(16, Math.min(+w || 400, 1600)); h = Math.max(16, Math.min(+h || 300, 1600));
  const fs = Math.max(10, Math.min(w, h) / 8);
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='${w}' height='${h}' viewBox='0 0 ${w} ${h}'><rect width='100%' height='100%' fill='#e5e7eb'/><text x='50%' y='50%' fill='#6b7280' font-family='sans-serif' font-size='${fs}' text-anchor='middle' dominant-baseline='middle'>${escXml((label || 'Image').slice(0, 40))}</text></svg>`;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}

// ---------- registry / relink ----------
const readPages = (dir) => (existsSync(join(dir, 'pages.json')) ? JSON.parse(readFileSync(join(dir, 'pages.json'), 'utf8')) : {});

function relinkHtml(html, pages) {
  return html.replace(TAG_RE, (full, name, attrStr, self) => {
    if (name.toLowerCase() !== 'a') return full;
    const attrs = parseAttrs(attrStr);
    const route = getAttr(attrs, 'data-static-route');
    if (route == null) return full;
    const file = pages[normRoute(decodeEntities(route))];
    delAttr(attrs, 'data-static-missing');
    if (file) setAttr(attrs, 'href', file);
    else { setAttr(attrs, 'href', '#'); attrs.push({ n: 'data-static-missing', v: null }); }
    return `<${name}${buildAttrs(attrs)}${self ? ' /' : ''}>`;
  });
}

function relink(dir) {
  if (!dir || !existsSync(dir)) { console.error(USAGE); process.exit(1); }
  const pages = readPages(dir);
  let n = 0;
  for (const f of readdirSync(dir).filter((x) => x.endsWith('.html'))) {
    const p = join(dir, f);
    const before = readFileSync(p, 'utf8');
    const after = relinkHtml(before, pages);
    if (after !== before) { writeFileSync(p, after); n++; }
  }
  console.log(`Relinked ${n} page(s) using ${Object.keys(pages).length} known route(s).`);
}

// ---------- convert ----------
async function convert(input) {
  const raw = input === '-' ? readFileSync(0, 'utf8') : readFileSync(input, 'utf8');
  const outDir = resolve(opts.out || 'static-demo');
  const assetsDir = join(outDir, 'assets');
  mkdirSync(assetsDir, { recursive: true });

  const pageUrl = opts.url ? new URL(opts.url) : null;
  const pageBase = pageUrl || new URL('http://static.local/');
  const route = normRoute(opts.route || (pageUrl ? pageUrl.pathname : '/'));
  const name = opts.name || slugOf(route);
  const localRoots = opts.localRoot.map((r) => resolve(r));

  const report = {
    page: { route, file: `${name}.html`, sourceUrl: pageUrl ? pageUrl.href : null },
    removed: { scripts: 0, preloadLinks: 0, handlers: 0, comments: 0, other: 0 },
    redactions: { emails: 0, tokens: 0, hiddenInputs: 0 },
    assets: { local: 0, downloaded: 0, remote: 0, placeholders: 0, unresolved: [] },
    links: { internalCaptured: 0, internalMissing: [], external: 0 },
    dataSignals: {},
    warnings: [],
  };

  // --- analysis that needs the scripts, before they are removed ---
  const scripts = [...raw.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi)];
  const apiRe = /["'`]((?:https?:\/\/[^"'`\s]+)?\/api\/[^"'`\s?]*)/g;
  const endpoints = new Set();
  for (const s of scripts) for (const m of s[1].matchAll(apiRe)) endpoints.add(m[1]);
  for (const m of raw.matchAll(/\b(?:href|src|action)="((?:https?:\/\/[^"]+)?\/api\/[^"?]*)/g)) endpoints.add(m[1]);
  let nextDataKeys = null;
  const nd = raw.match(/<script[^>]*id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/i);
  if (nd) { try { const d = JSON.parse(nd[1]); nextDataKeys = { top: Object.keys(d), pagePropKeys: Object.keys(d.props?.pageProps || {}) }; } catch { /* ignore */ } }
  report.dataSignals.apiEndpoints = [...endpoints].slice(0, 50);
  report.dataSignals.nextData = nextDataKeys;
  report.dataSignals.hasRscPayload = /self\.__next_f\.push/.test(raw);

  // --- strip scripts, noscript, comments, dev overlays ---
  let html = raw;
  html = html.replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/gi, () => (report.removed.scripts++, ''));
  html = html.replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript\s*>/gi, () => (report.removed.other++, ''));
  html = html.replace(/<(nextjs-portal|next-route-announcer)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, () => (report.removed.other++, ''));
  html = html.replace(/<!--[\s\S]*?-->/g, () => (report.removed.comments++, ''));

  // --- asset resolution ---
  const assetCache = new Map();
  function findLocal(pathname) {
    let p; try { p = decodeURIComponent(pathname); } catch { p = pathname; }
    for (const root of localRoots) {
      for (const cand of [p, p.replace(/^\/_next\//, '/')]) {
        const f = resolve(join(root, cand));
        if (f.startsWith(root + sep) && existsSync(f) && statSync(f).isFile()) return f;
      }
    }
    return null;
  }
  const extFromType = (t = '') => (/svg/.test(t) ? '.svg' : /png/.test(t) ? '.png' : /jpe?g/.test(t) ? '.jpg' : /webp/.test(t) ? '.webp' : /gif/.test(t) ? '.gif' : /css/.test(t) ? '.css' : /woff2/.test(t) ? '.woff2' : '');
  function assetName(key, pathname, type) {
    const base = basename(pathname).replace(/[^\w.-]+/g, '_').slice(0, 40) || 'asset';
    return `${sha(key)}-${base}${extname(base) ? '' : extFromType(type)}`;
  }
  function copyAsset(file) {
    if (assetCache.has(file)) return assetCache.get(file);
    const n = assetName(file, file);
    copyFileSync(file, join(assetsDir, n));
    const rel = `assets/${n}`;
    assetCache.set(file, rel);
    return rel;
  }
  async function download(url) {
    if (assetCache.has(url)) return assetCache.get(url);
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(String(res.status));
      const n = assetName(url, new URL(url).pathname, res.headers.get('content-type') || '');
      writeFileSync(join(assetsDir, n), Buffer.from(await res.arrayBuffer()));
      const rel = `assets/${n}`;
      assetCache.set(url, rel);
      return rel;
    } catch { assetCache.set(url, null); return null; }
  }
  async function fetchText(url) {
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(15000) });
      return res.ok ? await res.text() : null;
    } catch { return null; }
  }

  // returns { href|null, status }
  async function resolveAsset(ref, base = pageBase) {
    ref = decodeEntities(String(ref).trim());
    if (!ref || /^(data:|#|blob:|about:|javascript:)/i.test(ref)) return { href: ref, status: 'skip' };
    let abs;
    try { abs = new URL(ref.startsWith('//') ? 'https:' + ref : ref, base); } catch { return { href: null, status: 'unresolved' }; }
    if (abs.pathname === '/_next/image' && abs.searchParams.get('url')) return resolveAsset(abs.searchParams.get('url'), abs);
    if (!/^https?:$/.test(abs.protocol)) return { href: ref, status: 'skip' };
    const same = abs.origin === pageBase.origin;
    if (same) {
      const f = findLocal(abs.pathname);
      if (f) { report.assets.local++; return { href: copyAsset(f), status: 'local' }; }
    }
    // A localhost origin will not exist for whoever opens the demo, so keep it only if it can be downloaded
    const loopback = /^(localhost|127\.|\[::1\]|0\.0\.0\.0)|\.local$/.test(abs.hostname);
    if (opts['download-assets']) {
      const d = await download(abs.href);
      if (d) { report.assets.downloaded++; return { href: d, status: 'downloaded' }; }
    }
    if (!same || (pageUrl && !loopback)) {
      report.assets.remote++;
      return { href: abs.href, status: 'remote', abs };
    }
    report.assets.unresolved.push(ref);
    return { href: null, status: 'unresolved' };
  }

  async function replaceAsync(str, re, fn) {
    const matches = [...str.matchAll(re)];
    let out = '', pos = 0;
    for (const m of matches) { out += str.slice(pos, m.index) + (await fn(...m)); pos = m.index + m[0].length; }
    return out + str.slice(pos);
  }

  async function rewriteCssUrls(css, base) {
    css = await replaceAsync(css, /@import\s+(?:url\()?\s*["']?([^"')\s;]+)["']?\s*\)?/g, async (m, ref) => {
      try { return `@import url("${new URL(decodeEntities(ref), base).href}")`; } catch { return m; }
    });
    return replaceAsync(css, /url\(\s*(["']?)([^"')]+)\1\s*\)/g, async (m, _q, ref) => {
      const r = await resolveAsset(ref, base);
      return r.href ? `url("${r.href}")` : m;
    });
  }

  async function stylesheet(href, media) {
    const ref = decodeEntities(href);
    let abs; try { abs = new URL(ref.startsWith('//') ? 'https:' + ref : ref, pageBase); } catch { return ''; }
    const same = abs.origin === pageBase.origin;
    let css = null;
    const f = same ? findLocal(abs.pathname) : null;
    if (f) css = readFileSync(f, 'utf8');
    else if ((same && pageUrl) || (!same && opts['download-assets'])) css = await fetchText(abs.href);
    if (css != null) {
      css = await rewriteCssUrls(css, abs);
      return `<style data-source="${encAttr(abs.pathname)}"${media ? ` media="${media}"` : ''}>\n${css}\n</style>`;
    }
    const loopback = same && /^(localhost|127\.|\[::1\]|0\.0\.0\.0)|\.local$/.test(abs.hostname);
    if (!same || (pageUrl && !loopback)) return `<link rel="stylesheet" href="${encAttr(abs.href)}"${media ? ` media="${media}"` : ''}>`;
    report.assets.unresolved.push(ref);
    return '';
  }

  // --- per-tag rewrite ---
  const registryPages = readPages(outDir);
  registryPages[route] = `${name}.html`;
  const emailMap = new Map();

  async function processTag(name_, attrStr, self) {
    const tag = name_.toLowerCase();
    const attrs = parseAttrs(attrStr);

    for (const a of [...attrs]) {
      if (/^on[a-z]+$/i.test(a.n)) { delAttr(attrs, a.n.toLowerCase()); report.removed.handlers++; }
    }
    for (const n of ['integrity', 'crossorigin', 'nonce', 'referrerpolicy', 'fetchpriority', 'data-reactroot']) delAttr(attrs, n);
    const style = getAttr(attrs, 'style');
    if (style && /url\(/i.test(style)) setAttr(attrs, 'style', encAttr(await rewriteCssUrls(decodeEntities(style), pageBase)));

    const rebuild = () => `<${name_}${buildAttrs(attrs)}${self ? ' /' : ''}>`;

    switch (tag) {
      case 'base':
        report.removed.other++;
        return '';
      case 'meta': {
        const n = (getAttr(attrs, 'name') || '').toLowerCase();
        const he = (getAttr(attrs, 'http-equiv') || '').toLowerCase();
        if (/csrf|xsrf/.test(n) || he === 'content-security-policy' || he === 'refresh') { report.removed.other++; return ''; }
        return rebuild();
      }
      case 'link': {
        const rel = (getAttr(attrs, 'rel') || '').toLowerCase();
        const href = getAttr(attrs, 'href');
        if (/(^|\s)(preload|modulepreload|prefetch|dns-prefetch|preconnect|manifest)(\s|$)/.test(rel)) { report.removed.preloadLinks++; return ''; }
        if (rel.includes('stylesheet') && href) return stylesheet(href, getAttr(attrs, 'media'));
        if (/icon/.test(rel) && href) {
          const r = await resolveAsset(href);
          if (!r.href) return '';
          setAttr(attrs, 'href', encAttr(r.href));
        }
        return rebuild();
      }
      case 'img': {
        const lazy = getAttr(attrs, 'data-src');
        let src = lazy || getAttr(attrs, 'src');
        for (const n of ['srcset', 'sizes', 'loading', 'data-src', 'data-srcset']) delAttr(attrs, n);
        let out = null;
        if (src && !opts['placeholder-images']) {
          const r = await resolveAsset(src);
          if (r.href) out = r.href;
        }
        if (!out) {
          const keep = src && /^data:/i.test(decodeEntities(src)) && !opts['placeholder-images'];
          out = keep ? decodeEntities(src) : placeholder(getAttr(attrs, 'width'), getAttr(attrs, 'height'), decodeEntities(getAttr(attrs, 'alt') || 'Image'));
          if (!keep) report.assets.placeholders++;
        }
        setAttr(attrs, 'src', encAttr(out));
        return rebuild();
      }
      case 'source': {
        if (getAttr(attrs, 'srcset') != null) { report.removed.other++; return ''; }
        const src = getAttr(attrs, 'src');
        if (src) { const r = await resolveAsset(src); if (!r.href) return ''; setAttr(attrs, 'src', encAttr(r.href)); }
        return rebuild();
      }
      case 'video': case 'audio': case 'track': case 'embed': case 'iframe': {
        for (const k of ['src', 'poster']) {
          const v = getAttr(attrs, k);
          if (!v) continue;
          const r = await resolveAsset(v);
          if (r.href) setAttr(attrs, k, encAttr(r.href)); else delAttr(attrs, k);
        }
        if (tag === 'video' || tag === 'audio') { delAttr(attrs, 'autoplay'); }
        return rebuild();
      }
      case 'a': {
        const href = getAttr(attrs, 'href');
        delAttr(attrs, 'ping');
        if (href == null) return rebuild();
        const ref = decodeEntities(href).trim();
        if (/^(#|mailto:|tel:)/i.test(ref)) return rebuild();
        if (/^javascript:/i.test(ref)) { setAttr(attrs, 'href', '#'); return rebuild(); }
        let abs; try { abs = new URL(ref.startsWith('//') ? 'https:' + ref : ref, pageBase); } catch { return rebuild(); }
        if (abs.origin === pageBase.origin) {
          const r = normRoute(abs.pathname);
          setAttr(attrs, 'data-static-route', encAttr(r));
          const file = registryPages[r];
          delAttr(attrs, 'data-static-missing');
          if (file) { setAttr(attrs, 'href', file); report.links.internalCaptured++; }
          else { setAttr(attrs, 'href', '#'); attrs.push({ n: 'data-static-missing', v: null }); if (!report.links.internalMissing.includes(r)) report.links.internalMissing.push(r); }
          delAttr(attrs, 'target');
        } else {
          setAttr(attrs, 'href', encAttr(abs.href));
          if (!getAttr(attrs, 'rel')) attrs.push({ n: 'rel', v: 'noopener noreferrer' });
          report.links.external++;
        }
        return rebuild();
      }
      case 'form':
        delAttr(attrs, 'action');
        attrs.push({ n: 'data-static-form', v: null });
        return rebuild();
      case 'input': {
        const type = (getAttr(attrs, 'type') || 'text').toLowerCase();
        const nm = getAttr(attrs, 'name') || '';
        if (type === 'password' || (type === 'hidden' && /csrf|xsrf|token|nonce|auth|session|secret/i.test(nm))) {
          if (getAttr(attrs, 'value')) { setAttr(attrs, 'value', ''); report.redactions.hiddenInputs++; }
        }
        return rebuild();
      }
      default:
        return rebuild();
    }
  }

  async function processTags(src) {
    const jobs = [...src.matchAll(TAG_RE)];
    let out = '', pos = 0;
    for (const m of jobs) {
      out += src.slice(pos, m.index) + (await processTag(m[1], m[2], m[3]));
      pos = m.index + m[0].length;
    }
    return out + src.slice(pos);
  }

  html = await processTags(html);
  html = await replaceAsync(html, /(<style\b[^>]*>)([\s\S]*?)(<\/style>)/gi, async (_m, open, css, close) => {
    if (/data-source=/.test(open) || !/url\(|@import/.test(css)) return open + css + close;
    return open + (await rewriteCssUrls(css, pageBase)) + close;
  });

  // --- redaction ---
  if (!opts['no-redact']) {
    html = html.replace(/[\w.+-]+@[\w-]+(?:\.[\w-]+)*\.[A-Za-z]{2,}/g, (e) => {
      if (/\.(png|jpe?g|gif|svg|webp|avif|css|js|woff2?)$/i.test(e) || /@example\.com$/i.test(e)) return e;
      if (!emailMap.has(e)) emailMap.set(e, `user${emailMap.size + 1}@example.com`);
      report.redactions.emails++;
      return emailMap.get(e);
    });
    html = html.replace(/\beyJ[\w-]{10,}\.[\w-]{10,}\.[\w-]*|\b(?:ghp_|gho_|github_pat_|sk-|xox[baprs]-)[A-Za-z0-9_-]{16,}|\bAKIA[0-9A-Z]{16}\b/g, () => (report.redactions.tokens++, '[redacted-token]'));
  }

  // --- data signals (where dummy data is needed) ---
  const body = (html.match(/<body\b[^>]*>([\s\S]*?)(<\/body>|$)/i) || [, html])[1];
  const text = body.replace(/<style[\s\S]*?<\/style>/gi, '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  const count = (re) => (html.match(re) || []).length;
  report.dataSignals.skeletonElements = count(/class="[^"]*\b(animate-pulse|skeleton|shimmer|placeholder-glow|loading-skeleton)\b/g);
  report.dataSignals.ariaBusy = count(/aria-busy="true"/g);
  report.dataSignals.loadingText = count(/>\s*(Loading|Đang tải)[^<]{0,20}</gi);
  report.dataSignals.emptyContainers = count(/<(ul|ol|tbody)\b[^>]*>\s*<\/\1>/g);
  report.dataSignals.emptyAppRoot = /<div[^>]*id="(__next|root|app)"[^>]*>\s*<\/div>/.test(html);
  report.dataSignals.bodyTextLength = text.length;
  if (report.dataSignals.emptyAppRoot || text.length < 80)
    report.warnings.push('Page looks un-rendered (empty app root / almost no text). Copy the rendered DOM (DevTools > Elements > right-click <html> > Copy outerHTML) after the page finished loading, not View Source.');
  if (report.dataSignals.skeletonElements || report.dataSignals.ariaBusy || report.dataSignals.loadingText)
    report.warnings.push('Loading/skeleton markup found: replace with realistic dummy content.');
  if (report.assets.unresolved.length)
    report.warnings.push('Some assets could not be resolved. Re-run with --url <page-url> and/or --local-root <public,.next>, or use --tailwind-cdn / --placeholder-images.');

  // --- document shell + static runtime ---
  if (!/<html[\s>]/i.test(html)) html = `<html lang="en"><head></head><body>\n${html}\n</body></html>`;
  if (!/^\s*<!doctype/i.test(html)) html = '<!DOCTYPE html>\n' + html;
  if (!/<meta[^>]+charset/i.test(html)) html = html.replace(/<head\b[^>]*>/i, (h) => `${h}<meta charset="utf-8">`);
  if (!/<meta[^>]+name=["']viewport/i.test(html)) html = html.replace(/<head\b[^>]*>/i, (h) => `${h}<meta name="viewport" content="width=device-width, initial-scale=1">`);
  if (opts['tailwind-cdn']) html = html.replace(/<\/head>/i, '<script src="https://cdn.tailwindcss.com"></script></head>');

  const badge = opts['no-banner'] ? '' : `<div id="static-demo-badge" role="note" style="position:fixed;right:12px;bottom:12px;z-index:2147483000;background:#111827;color:#fff;font:12px/1.4 system-ui,sans-serif;padding:6px 10px;border-radius:999px;opacity:.85;cursor:pointer" title="Click to hide">Static demo &middot; dummy data</div>`;
  const runtime = `${badge}<script data-static-runtime>(function(){function toast(m){var t=document.createElement('div');t.textContent=m;t.setAttribute('role','status');t.style.cssText='position:fixed;left:50%;bottom:56px;transform:translateX(-50%);background:#111827;color:#fff;padding:10px 16px;border-radius:8px;font:14px system-ui,sans-serif;z-index:2147483001';document.body.appendChild(t);setTimeout(function(){t.remove()},2500)}document.addEventListener('submit',function(e){e.preventDefault();toast('Demo mode: nothing was sent.')},true);document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[data-static-missing]');if(a){e.preventDefault();toast('This page is not part of the demo ('+a.getAttribute('data-static-route')+').')}var b=e.target.closest&&e.target.closest('#static-demo-badge');if(b)b.remove()},true)})();</script>`;
  html = /<\/body>/i.test(html) ? html.replace(/<\/body>/i, runtime + '</body>') : html + runtime;

  writeFileSync(join(outDir, `${name}.html`), html);
  writeFileSync(join(outDir, 'pages.json'), JSON.stringify(registryPages, null, 2));
  writeFileSync(join(outDir, `${name}.analysis.json`), JSON.stringify(report, null, 2));

  const d = report.dataSignals;
  console.log(`Wrote ${join(outDir, name + '.html')}  (route ${route})`);
  console.log(`Removed: ${report.removed.scripts} scripts, ${report.removed.preloadLinks} preload/prefetch links, ${report.removed.handlers} inline handlers, ${report.removed.comments} comments`);
  console.log(`Assets: ${report.assets.local} local, ${report.assets.downloaded} downloaded, ${report.assets.remote} remote, ${report.assets.placeholders} placeholders, ${report.assets.unresolved.length} unresolved`);
  console.log(`Redacted: ${report.redactions.emails} emails, ${report.redactions.tokens} tokens, ${report.redactions.hiddenInputs} sensitive inputs`);
  console.log(`Links: ${report.links.internalCaptured} linked to captured pages, ${report.links.internalMissing.length} to missing pages${report.links.internalMissing.length ? ' (' + report.links.internalMissing.join(', ') + ')' : ''}`);
  console.log(`Data signals: skeletons=${d.skeletonElements} busy=${d.ariaBusy} loadingText=${d.loadingText} emptyLists=${d.emptyContainers} apiEndpoints=${d.apiEndpoints.length}${d.apiEndpoints.length ? ' [' + d.apiEndpoints.slice(0, 6).join(', ') + ']' : ''}`);
  for (const w of report.warnings) console.log(`WARNING: ${w}`);
}

if (opts.help || !opts._.length) { console.log(USAGE); process.exit(opts.help ? 0 : 1); }
if (opts._[0] === 'relink') relink(opts._[1]);
else {
  if (opts._[0] === 'convert') opts._.shift();
  if (!opts._[0]) { console.error(USAGE); process.exit(1); }
  await convert(opts._[0]);
}
